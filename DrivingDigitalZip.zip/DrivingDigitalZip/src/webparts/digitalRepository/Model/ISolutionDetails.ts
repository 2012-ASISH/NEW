import { IDropdownOption } from "office-ui-fabric-react";

export interface ISolutionDetails {
    Id: string;
    SolutionName: string;
    SolutionType: string;
    SolutionVersion: string;
    SolutionDescription: string;
    SolutionSector: string;
    SolutionArea: string;
    SolutionRegion: string;
    SolutionOwnerId: number;
    SolutionContributorsId: number[];
    SolutionOwner: string;
    SolutionContributors: string[];
    ProjectImage: any;
    Technology: string;
    Views: number;
    Downloads: number;
    Likes: number;
    ViewCount: number;
    LikesCount: number;
    ViewsCount: number;

    
   /* TeamBenefits: string;
    SolutionEnhance: string;
    EstimatedHours: string;
    SolutionStatus: string;
    SolutionId: string;
    SolutionPrimaryObjective: string;
    SolutionRelatedAccountAuditArea: string;    
    SolutionSummaryChanges: string;
    SolutionPromptedChange: string;*/
  }

  export interface ISubmitSolutionDetails {
    SolutionName: string;
    SolutionType: string;
   // SolutionVersion: string;
    SolutionDescription: string;
    SolutionSector: string;
    SolutionArea: string;
    SolutionRegion: string;
    SolutionOwnerId: number;
    SolutionContributorsId: number[];
    SolutionOwner: string;
    SolutionContributors: string[];
    SolutionPPEDSponsorId: number;    
    SolutionPPEDSponsor: string;
    TeamBenefits: string;
    SolutionEnhance: string;
    SolutionEnhanceYesNo: boolean;
    EstimatedHours: string;
    SolutionStatus: string;
    SolutionId: string;
    SolutionPrimaryObjective: string;
    SolutionPrimaryObjectiveOther: string;
    SolutionRelatedAccountAuditArea: string;    
    SolutionSummaryChanges: string;
    SolutionPromptedChange: string;
    Ack1_Column: boolean;
    Ack2_Column: boolean;
    Ack3_Column: boolean;
    Ack4_Column: boolean;
  }

  export interface IGDSSolutionItem{
    Id: number;
    Title: string;
    SolutionOwnerId: string;
    SolutionOwnerTitles: string[];
    SolutionOwner: string;
    SolutionDescription: string;
    Technology: string;
    SubServiceLine1: string;
    Category: string;
    SPOCId: string;
    SPOCTitles: string[];
    SPOC: string;
    ReviewerId: string;
    ReviewerTitles: string[];
    Reviewer: string;
    Reusability: boolean;
    GoLive: string;
    GDSLocation: string;
    BusinessProblem: string;
    Area: string;
    Status: string;
    Created: string;
    Modified: string;
    Views: string;
    Downloads: string;
    Likes: string;
    ProjectImage: any;
    ViewsCount: number;
    LikesCount: number;
    DownloadsCount: number;
    AuditPhase:string[];
    RequestTags:string[];
    CertificationType:string;
    CertifiedRegion:string[];
    DemoVideoLink:{
      Description: string;
      Url: string;
    };
    EstSavingsPerEngagementInHours: number;
    SolutionRequireForm114Usage:string;

    GDSName: string;
    GDSAck1: boolean;
    GDSAck2: boolean;
    GDSAck3: boolean;
    GDSAck4: boolean;   
    GDSAck5: boolean; 
    GDSSolutionDescription: string;
    GDSBenefitsOfTeamDescription: string;
    GDSSolutionEnhanceYesNo: boolean;
    GDSSolutionEnhancements: string;
    GDSEstimatedHours: string;
    GDSPrimaryObjective: string;
    GDSAreaCertified: string;
    //GDSRegionalGeography: string; 
    GDSRegionalGeography: string[];
    //GDSRegionalGeographyTitles: string[]; 
    //GDSApplicableSector: string;
    GDSRestrictedTo: string[];
    GDSApplicableSectorMulti: string[];
    GDSApplicableSectorMultiTitles: string[];
    GDSRelatedAccount: string;
    GDSSolutionType: string;
    GDSSolutionTypeMulti: string[];
    GDSSolutionTypeMultiTitles: string[];
    GDSVersion: string;
    GDSSolutionOwnerTitles: string[];
    GDSSolutionOwner: string;
    GDSSolutionOwnerId:string;
    GDSSolutionContributorsTitles: string[];
    GDSSolutionContributors: string[];
    GDSSolutionContributorsId: string[];
    GDSPPEDDSponsorId: string;
    GDSPPEDDSponsorTitles: string[];
    GDSPPEDDSponsor: string;
    GDSStatus: string;
    GDSSolutionID: string;
    GDSSummaryOfChanges: string;
    GDSPromptedTheChange: string
    GDSPrimaryObjectiveOther: string;
    //GDSApprovedForUse: string;
    //GDSRestrictedTo: string;

    FormName: string;
    GDSNewOrUpdateSolution:string;
  }



  export interface IGDSSupportItem{  
    Id: string;
    Title: string;
    GDSSupportAreaOwners: string[];
    GDSSupportAreaReviewers: string[];    
    GDSSupportCertifiedSolutions: string;
    GDSSupportCertifications: string;
    GDSSupportPolicyLink: string;
    GDSSupportYammerLink: string;
    GDSWorkflowStep1: string;
    GDSWorkflowStep2: string;    
    GDSWorkflowStep3: string;
    GDSWorkflowStep4: string;
    GDSWorkflowFinalStep: string;    
  }

 
  export interface IdigitalRackDropdown {
    RequestTags?:Array<IDropdownOption>;
  }


  export interface IGDSTrackLikesItem{
    Id: string;
    Title: string;
    GDSSolutionID: string;
    GDSTrackLikes: number;
    GDSDownloads: number;
    GDSLikesUsers: string;
    eTag: any;
  }

  export interface IGDSSolutionOwnerAnnualConfirmationItem{
    Id: string;
    Title: string;
    GDSSolutionID: string;
    GDSAnnualConfirmation: boolean;    
  }

  export interface IGDSConfigurationItem{
    Id: string;
    Title: string;
    Value: string;
    GDSDate: string;
  }

export interface IGDSAreaList {
    Title: string;    
  }

  export interface IGDSSectorList {
    Id: string;
    Title: string;    
  }

  export interface IGDSRegionList {
    Title: string;
    Area: string;
  }

  export interface IGDSSolutionTypeList {
    Id: string;
    Title: string;    
  }

  export interface IGDSPrimaryObjectiveList {
    Title: string;    
  }

  export interface IGDSPromptedChangeList {
    Title: string;    
  }

  export interface IGDSDropDownStruct{
    key: string;
    text: string;
    disabled: boolean;
  }

  export interface IGDSMultiDropDownStruct{
    key: number;
    text: string;
    disabled: boolean;
  }

  export interface IGDSRadioOptionStruct{
    key: string;
    text: string;
  }

  export interface IGDSUserDetails{
    Title: string;
    Email: string;
    LoginName: string;
  }