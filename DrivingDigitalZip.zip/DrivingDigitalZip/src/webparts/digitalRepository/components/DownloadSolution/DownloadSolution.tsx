import * as React from 'react';
import { IDownloadSolutionProps } from './IDownloadSolutionProps';
import { IDownloadSolutionState } from './IDownloadSolutionState';
import { mergeStyleSets } from 'office-ui-fabric-react/lib/Styling';
import { GDSDropDown } from '../FabricUiComponents/GDSDropDown';
import { GDSTextField } from '../FabricUiComponents/GDSTextField';
import * as constants from '../../constants';
import { Web } from 'sp-pnp-js';
import {
  getTheme,
  FontWeights,
  Modal,
  IconButton,
  IIconProps,
  DatePicker, 
  DefaultButton
} from 'office-ui-fabric-react';

const cancelIcon: IIconProps = { iconName: 'Cancel' };
const theme = getTheme();
const contentStyles = mergeStyleSets({
  container: {
    display: 'flex',
    flexFlow: 'column nowrap',
    alignItems: 'stretch',
    width: "500px"
  },
  header: [
    theme.fonts.xLargePlus,
    {
      flex: '1 1 auto',
      borderTop: `0px solid ${theme.palette.themePrimary}`,
      color: theme.palette.neutralPrimary,
      display: 'flex',
      alignItems: 'center',
      fontWeight: FontWeights.semibold,
      padding: '12px 12px 14px 24px',
    },
  ],
  body: {
    flex: '4 4 auto',
    padding: '0 24px 24px 24px',
    overflowY: 'hidden',
    selectors: {
      p: { margin: '14px 0' },
      'p:first-child': { marginTop: 0 },
      'p:last-child': { marginBottom: 0 },
      label:{
        color:'#ffe600'
      }
    },
  },
});
const iconButtonStyles = {
  root: {
    color: '#fff',
    marginLeft: 'auto',
    marginTop: '4px',
    marginRight: '2px',
  },
  rootHovered: {
    color: theme.palette.neutralDark,
  },
};

export class DownloadSolution extends React.Component<IDownloadSolutionProps, IDownloadSolutionState> {

  private nextStates = {
    UsageDescription: "",
    SubServiceLine: "",
    PlannedImplementationDate: null,
    PotentialSavings: ""
  };

  private errorStates = {
    UsageDescription: "",
    SubServiceLine: "",
    PlannedImplementationDate: null,
    PotentialSavings: ""
  };

  constructor(props) {
    super(props);

    this.state = {
      initialDownloadSolutionStates: this.nextStates,
      Errors: this.errorStates
    };
  };

  private handleChange = (columnName, value) => {
    if (value.key) {
      this.setStateAcknowledgeFields(columnName, value.key);
    }
    else{
      this.setStateAcknowledgeFields(columnName, value);
    }
  }

  private setStateAcknowledgeFields(columnName: any, value: any) {
    this.setState(prevState => ({
      initialDownloadSolutionStates: {                   // object that we want to update
        ...prevState.initialDownloadSolutionStates,    // keep all other key-value pairs
        [columnName]: value       // update the value of specific key
      },
      Errors: {
        ...prevState.Errors,
        [columnName]: ""
      }
    }));
  }

  private closeDownloadSolutionModal = (): void => {
      this.setState({
        Errors: {
          UsageDescription:"",
          SubServiceLine: "",
          PlannedImplementationDate: null,
          PotentialSavings: ""
        }
      });
      this.props.parentCallback(false);
    }
  //-Validate the submitted date------------------
  private ValidateEditRequestForm() {
    const errors = [];
    let errorObj = {};
    const numbers = /^[0-9]+$/; //Only Number Regex
    if (this.state.initialDownloadSolutionStates.PotentialSavings === '' || this.state.initialDownloadSolutionStates.PotentialSavings === null) {
      errorObj["PotentialSavings"] = "Potential Savings can't be empty";
  } 
  else{
    var re = /^[0-9]*$/;
   var value = re.test(this.state.initialDownloadSolutionStates.PotentialSavings)

   if(value === false || this.state.initialDownloadSolutionStates.PotentialSavings.toString().length > 10){
    errorObj["PotentialSavings"] = "Enter valid Potential Savings";
   }   
  }
   if (this.state.initialDownloadSolutionStates.PlannedImplementationDate === '' || this.state.initialDownloadSolutionStates.PlannedImplementationDate === null) {
    errorObj["PlannedImplementationDate"] = "Planned Implementation Date can't be empty";
}
if (this.state.initialDownloadSolutionStates.SubServiceLine === '' || this.state.initialDownloadSolutionStates.SubServiceLine === null) {
  errorObj["SubServiceLine"] = "Sub Service Line can't be empty";
}
if (this.state.initialDownloadSolutionStates.UsageDescription === '' || this.state.initialDownloadSolutionStates.UsageDescription === null) {
  errorObj["UsageDescription"] = "Usage description can't be empty";
}
   if (Object.keys(errorObj).length != 0 && errorObj.constructor === Object)
   errors.push(errorObj);
   return errors;
  }
  //-----------------------Submit changed data--------------------  
  private submitDownloadSolution = () => {
   //this.startDownloading();
    const errors = this.ValidateEditRequestForm();
    if (errors.length > 0) {
      this.setState({
         Errors: errors[0]
      })
    }
    else{
    let submitData = {
      Title : this.props.solutionName,
      SolutionID : this.props.solutionID,
      SubServiceLine: this.state.initialDownloadSolutionStates.SubServiceLine,
      PlannedImplementationDate: this.state.initialDownloadSolutionStates.PlannedImplementationDate,
      PotentialSavings: this.state.initialDownloadSolutionStates.PotentialSavings,
      UsageDescription: this.state.initialDownloadSolutionStates.UsageDescription
    } 
    let web = new Web(this.props.context.pageContext.web.absoluteUrl);
    web.lists.getByTitle("Downloads").items.add(submitData).catch(error => { 
      console.log(error);
    });
    web.lists.getByTitle("Automation Rack").items.getById(this.props.solutionID).update({DownloadsCount:this.props.downloads+1}).catch(error => { 
      console.log(error);
    });
    this.closeDownloadSolutionModal();
  }
}
//---------------------------------------------------------------
//----------------------------------------------------------------
  public render() {
      return <Modal
      titleAriaId="DM"
      isOpen={this.props.showDownloadModal}
      isBlocking={false}
      containerClassName={contentStyles.container}
      // dragOptions={isDraggable ? dragOptions : undefined}
      >
      <div className={contentStyles.header}>
        <span style={{ marginRight: "10px", color: "#ffe600" }}>Download Request</span>
          <IconButton
              styles={iconButtonStyles}
              iconProps={cancelIcon}
              ariaLabel="Close popup modal"
              onClick={this.closeDownloadSolutionModal.bind(this)}
          />
      </div>

      <div className={contentStyles.body}>
          <div className="ms-Grid-col  ms-sm4 ms-md4 ms-lg4" style={{color:'#ffe600'}}>
            <GDSTextField
                multiline={true}
                label="Usage description"
                placeholder="Enter usage description"
                onChange={this.handleChange.bind(this, "UsageDescription")}
                errorMessage={this.state.Errors.UsageDescription}
            ></GDSTextField>
          </div>
          <div className="ms-Grid-col  ms-sm4 ms-md4 ms-lg4" >
            <GDSDropDown options={this.props.subServiceLines} 
            label={"Sub service line"}
            placeholder={"Select"}
            selectedKey={this.state.initialDownloadSolutionStates.SubServiceLine}
            onChange={this.handleChange.bind(this, "SubServiceLine")}
            errorMessage={this.state.Errors.SubServiceLine}
            />
          </div>
          <div className="ms-Grid-col  ms-sm4 ms-md4 ms-lg4" >
            <DatePicker  label={"Planned implementation date"}
            placeholder={"Select planned implementation date"}
            minDate={new Date()}
            value={this.state.initialDownloadSolutionStates.PlannedImplementationDate}
            onSelectDate={(date)=>{
              this.state.initialDownloadSolutionStates.PlannedImplementationDate = date;
              this.setState({initialDownloadSolutionStates: this.state.initialDownloadSolutionStates});
            }}
            />
          {this.state.Errors.PlannedImplementationDate != '' && 
          <div className='msmErrorMessage'>{this.state.Errors.PlannedImplementationDate}</div>}
          </div>
          <div className="ms-Grid-col  ms-sm4 ms-md4 ms-lg4" style={{color:'#ffe600'}}>
            <GDSTextField label={"Potential Savings"}
              onChange={this.handleChange.bind(this, "PotentialSavings")}
              errorMessage={this.state.Errors.PotentialSavings}
              placeholder="Enter potential savings"
            />
          </div>
        </div>
        <div style={{padding:'0 0 20px 24px'}}>
          <DefaultButton style={{ marginRight: "10px", background: "#fe0", color: "#000" }} className="MuiStepIcon-text" onClick={this.submitDownloadSolution.bind(this)} text="Submit" />
          <DefaultButton className="MuiStepIcon-text" onClick={this.closeDownloadSolutionModal.bind(this)} text="Cancel" />
        </div>
    </Modal>;
    }

    private startDownloading() {
      let webitem = new Web(this.props.context.pageContext.web.absoluteUrl).lists.getByTitle(constants.SPFXConstants.Constants.AutomationRack).items.getById(this.props.solutionID);
      webitem.attachmentFiles.get().then(attachments => {
        attachments.map((attachment, index) => {
          let iframe = document.createElement('iframe');
          iframe.style.visibility = 'collapse';
          document.body.appendChild(iframe);
          var downloadAttachmentUrl = this.props.context.pageContext.web.serverRelativeUrl + "/_layouts/download.aspx";
          iframe.contentDocument.write(
              `<form action="${downloadAttachmentUrl}" method="GET">
                      <input name="SourceUrl" id="SourceUrl" value="${attachment.ServerRelativeUrl.replace(/\"/g, '"')}">
                  </form>`
          );
          iframe.contentDocument.forms[0].submit();
          setTimeout(() => iframe.remove(), 2000);
        });
      }).catch(function (err) {
          alert(err);
      });
    }
  }
