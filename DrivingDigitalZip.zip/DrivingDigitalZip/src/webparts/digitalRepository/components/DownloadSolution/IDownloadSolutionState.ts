export interface IDownloadSolutionState {
  Errors: any;
  initialDownloadSolutionStates: any;
}