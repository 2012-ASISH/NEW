import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "@microsoft/sp-http";
// import { IViewrequestProps } from '../IViewrequestProps';

export interface IDownloadSolutionProps{
  context: WebPartContext;
  spHttpClient: SPHttpClient;
  parentCallback: any;
  subServiceLines: any;
  solutionID: number;
  solutionName: string;
  downloads:number;
  // updateRequest: any;
  showDownloadModal: boolean;
  // updateHistory: any;
}
  