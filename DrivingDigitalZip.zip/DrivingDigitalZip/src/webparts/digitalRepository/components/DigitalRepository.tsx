import * as React from 'react';
import styles from './DigitalRepository.module.scss';
import { IDigitalRepositoryProps } from './IDigitalRepositoryProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { DigitalRack } from './DigitalRack/DigitalRack';
import * as constants from "../constants";
import { Route, Switch, BrowserRouter, Redirect, Link, NavLink } from "react-router-dom";

export default class DigitalRepository extends React.Component<IDigitalRepositoryProps, {}> {
  private routerContext = null;
  // public componentDidMount() {
  //   window.sessionStorage.setItem("ShowPopup", "true");
  // }
  public render(): React.ReactElement<IDigitalRepositoryProps> {
    let basename: string = this.props.context.pageContext.web.serverRelativeUrl.toLowerCase();
    let pathName: string = window.location.pathname.toLowerCase();
    let homePagePath: string = constants.SPFXConstants.Routing.HomePagePath;
    
    return (
      <div className={ styles.digitalRepository }>
        {/* <AllRequests {...this.props}/>} /> */}
        <div>
        <BrowserRouter basename={this.props.context.pageContext.web.serverRelativeUrl}>
          
          <Switch>
                  <Route exact path={homePagePath} component={(e) => {
                    this.routerContext = e;
                    return <DigitalRack {...this.props} routerContext={this.routerContext} context={this.props.context} spHttpClient={this.props.spHttpClient} />;
                  }}
                  />
                  <Route exact path={constants.SPFXConstants.Routing.ToolDetails}  component={(e) => {
                    this.routerContext = e;
                    return <DigitalRack {...this.props} routerContext={this.routerContext} context={this.props.context} spHttpClient={this.props.spHttpClient} />;
                  }}
                  />
                  </Switch>
                  
        </BrowserRouter>
        </div>
      </div>
    );
  }
}
