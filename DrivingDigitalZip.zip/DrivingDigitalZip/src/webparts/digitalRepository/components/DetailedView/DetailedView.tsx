import * as React from "react";
import * as constants from "../../constants";
import { IDetailedViewProps } from "./IDetailedViewProps";
import { IDetailedViewState } from "./IDetailedViewState";
import { GDSService } from "../../Service/GDSService";
import {
  Dialog,
  DialogType,
  DialogFooter,
} from "office-ui-fabric-react/lib/Dialog";
import { DefaultButton } from "office-ui-fabric-react/lib/Button";
import { Web } from "sp-pnp-js";
import { Image } from "office-ui-fabric-react/lib/Image";
import { DownloadSolution } from "../DownloadSolution/DownloadSolution";
import Slider from "react-slick";
import { sp } from "@pnp/sp";
import "@pnp/sp/attachments";

export class DetailedView extends React.Component<
  IDetailedViewProps,
  IDetailedViewState
> {
  private currentuseremail: string = "";

  constructor(props) {
    super(props);

    this.state = {
      DetailedViewItem: this.props.ViewDetailedItem,
      DownloadDialog: false,
      DownloadAttachments: [],
      ClickDownloadAttachments: false,
      Errors: [],
      ShowErrors: false,
      ShowDialog: {
        show: false,
        title: "",
        subtext: "",
      },
      Attachments: [],
      AcknowledgeCheckBoxState: false,
      TrackLikesData: [],
      userLiked: false,
      SliderImages: [],
    };
  }

  public componentDidMount() {
    GDSService.getCurrentUserInfo().then((res) => {
      this.currentuseremail = res;
      let tempuserlikes = JSON.parse(this.state.DetailedViewItem.Likes || "[]");
      this.setState({
        userLiked:
          tempuserlikes.filter((user) => user.email == this.currentuseremail)
            .length > 0,
      });
      this.LikeDownloadTracker(this.state.DetailedViewItem.Id, "View");
    });
    GDSService.getSliderImages(this.state.DetailedViewItem.Id).then((res) => {
      this.setState({ SliderImages: res });
    });
    this.getAttachements();
  }

  public render() {
    return <div>{this.RenderForm()}</div>;
  }

  RenderForm(): React.ReactNode {
    return (
      <div>
        <div className="solution-details">{this.RenderViewForm()}</div>
        {this.state.DownloadDialog ? this.RenderDownloadDialog() : null}
        {/* {this.state.ClickDownloadAttachments && this.state.DownloadAttachments.length > 0 && this.startDownloading()} */}
        {this.state.ShowDialog.show
          ? this.RenderErrorDialog(this.state.ShowDialog)
          : null}
      </div>
    );
  }

  private RenderDownloadDialog(): React.ReactNode {
    return (
      <DownloadSolution
        context={this.props.context}
        showDownloadModal={true}
        spHttpClient={this.props.spHttpClient}
        subServiceLines={this.props.subServiceLines}
        solutionID={this.state.DetailedViewItem.Id}
        solutionName={this.state.DetailedViewItem.Title}
        downloads={this.state.DetailedViewItem.DownloadsCount}
        parentCallback={(status: boolean) => {
          this.setState({
            DownloadDialog: status,
          });
        }}
      />
    );
  }

  // RenderDownloadDialog(): React.ReactNode {
  //     return <Dialog
  //         hidden={!this.state.DownloadDialog}
  //         onDismiss={this._closeDialog.bind(this, "Download")}
  //         dialogContentProps={{
  //             type: DialogType.normal,
  //             title: 'Before you download, please read.',
  //             closeButtonAriaLabel: 'Close',
  //             //subText: 'Report Bugs or Defects'
  //         }}
  //         modalProps={{
  //             isBlocking: false,
  //             styles: { main: { maxWidth: '500px !important', width: '100% !important' } }
  //         }}
  //     >
  //         <div className="mt-10">
  //             The Solution you are about to download has been certified by the area and approved for use only in the geographies listed. The certification is invalid if used in unapproved geographies.
  //         </div>
  //         <div className="termscond">
  //             <div className="termscondText"><u>I have read and understand my responsibilities as described</u></div>
  //             <div className="termscondChkbox"><GDSCheckbox label=""
  //                 isChecked={this.state.AcknowledgeCheckBoxState}
  //                 onChange={this.onCheckBoxChange.bind(this)} /></div>
  //         </div>
  //         {/* <button className="btn btn-yellow" onClick={this.DownloadAttachments.bind(this, this.state.DetailedViewItem.Id)}><i className="fa fa-download"></i> Download</button>            */}
  //         <DialogFooter>
  //             <DefaultButton className="view-sol-form-btn btn-yellow" disabled={!this.state.AcknowledgeCheckBoxState} onClick={this.DownloadAttachments.bind(this, this.state.DetailedViewItem.Id)} text="Download" />
  //         </DialogFooter>

  //     </Dialog>
  // };

  onCheckBoxChange(value): any {
    this.setState((prevState) => ({
      AcknowledgeCheckBoxState: !prevState.AcknowledgeCheckBoxState,
      ClickDownloadAttachments: false,
    }));
  }

  RenderViewForm(): React.ReactNode {
    let settings = {
      dots: true,
      infinite: true,
      speed: 1000,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 4000,
      cssEase: "linear",
    };
    let solution = this.state.DetailedViewItem;
    // return this.state.DetailedViewItem.map((solution, index) => {
    //var areaStampImageName = this.getAreaStampImageName(solution.GDSAreaCertified);
    return (
      <div>
        <Image
          className="create-sol-form-image"
          src={solution.ProjectImage["Url"]}
          alt={solution.Title}
        />
        <div className="create-sol-form-header">
          <div className="linerow">
            <div className="col-md-12">
              <a className="back-link" onClick={this.onBackClick.bind(this)}>
                <i className="fa fa-arrow-left"></i> Back
              </a>
              <div className="create-sol-form-header-title">
                <h2>{solution.Title}</h2>
              </div>
            </div>
            <div className="col-md-6">
              <p>
                <span>Last updated date</span>
                {GDSService.getDateFormat(solution.Modified)}
              </p>
            </div>
          </div>
        </div>
        <div className="create-sol-form-body mt-1">
          <div className="linerow">
            <div className="col-md-12">
              <div className="linerow">
                <div className="col-md-3">
                  <p className="view-sol-label-col">
                    <span>Technology : </span>
                    <b>{solution.Technology}</b>
                    <br />
                    <span>Sub Service Line : </span>
                    <b>{solution.SubServiceLine1}</b>
                    <br />
                    <span>Area : </span>
                    <b>{solution.Area}</b>
                    <br />
                  </p>
                </div>
                <div className="col-md-3">
                  <p className="view-sol-label-col">
                    <span>Certified : </span>
                    <b>{solution.CertificationType}</b>
                    <br /> <span>Solution Require Form 114 Usage : </span>
                    <b>{solution.SolutionRequireForm114Usage}</b> <br />
                    <span>Est Savings Per Engagement(Hours) : </span>
                    <b>{solution.EstSavingsPerEngagementInHours}</b>
                  </p>
                </div>
                <div className="col-md-3"></div>
                <div className="col-md-3">
                  <button
                    style={{
                      borderColor: "transparent",
                      backgroundColor: "transparent",
                      color: this.state.userLiked ? "#ffe600" : "#fff",
                    }}
                    className={`btn mr`}
                    onClick={this.onLikeClick.bind(this, solution.Id)}
                  >
                    <i
                      style={{ fontSize: "2.5em" }}
                      className="fa fa-thumbs-up"
                    ></i>{" "}
                    {this.state.DetailedViewItem.LikesCount || 0}
                  </button>
                  <button
                    style={{
                      background: "#fe0",
                      color: "#000",
                      width: "160px",
                    }}
                    className="view-sol-form-btn"
                    onClick={this.openDownloadDialog.bind(this)}
                  >
                    <i className="fa fa-download"></i> Request Solution
                  </button>
                </div>
              </div>

              <div className="linerow">
                <div className="col-md-3">
                  {solution.CertifiedRegion.length > 0 ? (
                    <p className="view-sol-label-col">
                      <span>Certified for : </span>
                      {solution.CertifiedRegion.map((e: any) => {
                        return e.Title;
                      })}
                    </p>
                  ) : null}

                  <p>{solution.GDSSolutionDescription}</p>
                </div>
              </div>
              <hr />
              <div className="linerow">
                <div className="col-md-6">
                  <h4 className="view-sol-label-header">Business Problem</h4>
                  <p>{solution.BusinessProblem}</p>
                </div>
                <div className="col-md-6">
                  <h4 className="view-sol-label-header">
                    Solution Description
                  </h4>
                  <p>{solution.SolutionDescription}</p>
                </div>
              </div>
              <div className="linerow">
                <div className="col-md-6">
                  <h4 className="view-sol-label-header">Solutions support</h4>
                  <ul className="sol-owner">
                    <li>
                      <div className="user-img-2">
                        <img
                          src={
                            constants.SPFXConstants.Constants.UserPhotoUrlSize +
                            solution.SolutionOwner["EMail"]
                          }
                        />
                      </div>
                      <div className="user-name">
                        <p>{solution.SolutionOwner["Title"]}</p>
                        <span>Solution owner</span>
                      </div>
                    </li>
                  </ul>
                  <ul className="sol-contri">
                    <li>
                      <div className="user-img-2">
                        <img
                          src={
                            constants.SPFXConstants.Constants.UserPhotoUrlSize +
                            solution.SPOC["EMail"]
                          }
                        />
                      </div>
                      <div className="user-name">
                        <p>{solution.SPOC["Title"]}</p>
                        <span>Digital Champion</span>
                      </div>
                    </li>
                  </ul>
                </div>
                <div className="col-md-6">
                  <br />
                  <div
                    className="slider-col-img-6"
                    style={{ width: 400, paddingLeft: 100 }}
                  >
                    <Slider {...settings}>
                      {this.state.SliderImages.map((i) => {
                        return (
                          <Image
                            // imageFit={ImageFit.centerCover}
                            style={{ width: "100%", height: "100%" }}
                            src={i}
                          />
                        );
                      })}
                    </Slider>
                  </div>
                </div>
              </div>
              <div className="linerow">
                {this.state.DetailedViewItem.DemoVideoLink ? (
                  <div className="col-md-6">
                    <h4 className="view-sol-label-header">
                      Related Enablement Material
                    </h4>
                    <a
                      href={this.state.DetailedViewItem.DemoVideoLink.Url}
                      style={{ color: "white" }}
                      target="_blank"
                    >
                      Click here to see Enablement material
                    </a>
                  </div>
                ) : null}
                {this.state.Attachments.length > 0 ? (
                  <div className="col-md-6">
                    <h4 className="view-sol-label-header">
                      Solution documents
                    </h4>
                    {this.state.Attachments.map((att) => {
                      return (
                        <div
                          onClick={() => {
                            this.downloadAttachment(att.ServerRelativeUrl);
                          }}
                          style={{
                            color: "white",
                            cursor: "pointer",
                            textDecoration: "underline",
                          }}
                        >
                          {att.FileName}
                        </div>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  onLikeClick = (
    solutionId: string,
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>
  ): void => {
    event.stopPropagation();
    this.LikeDownloadTracker(solutionId, "Like");
  };

  private getAttachements() {
    sp.web.lists
      .getByTitle(constants.SPFXConstants.Constants.AutomationRack)
      .items.getById(this.state.DetailedViewItem.Id)
      .attachmentFiles.get()
      .then((files) => {
        let attachments = [];
        files.map((file) => {
          attachments.push({
            FileName: file.FileName,
            ServerRelativeUrl: file.ServerRelativeUrl,
          });
        });
        this.setState({ Attachments: attachments });
      });
  }

  private downloadAttachment(url: string) {
    let iframe = document.createElement("iframe");
    iframe.style.visibility = "collapse";
    document.body.appendChild(iframe);
    let downloadAttachmentUrl =
      this.props.context.pageContext.web.serverRelativeUrl +
      "/_layouts/download.aspx";
    iframe.contentDocument.write(
      `<form action="${downloadAttachmentUrl}" method="GET">
                        <input name="SourceUrl" id="SourceUrl" value="${url.replace(
                          /\"/g,
                          '"'
                        )}">
                   </form>`
    );
    iframe.contentDocument.forms[0].submit();
    setTimeout(() => iframe.remove(), 2000);
  }

  DownloadAttachments = (
    itemId: any,
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>
  ): void => {
    if (this.state.DownloadAttachments.length === 0) {
      let web = new Web(this.props.context.pageContext.web.absoluteUrl);
      let webitem = new Web(
        this.props.context.pageContext.web.absoluteUrl
      ).lists
        .getByTitle(constants.SPFXConstants.Constants.AutomationRack)
        .items.getById(itemId);
      webitem.attachmentFiles
        .get()
        .then((attachmentArray) => {
          this.setState(
            (prevState) => ({
              DownloadAttachments: attachmentArray,
            }),
            () => {
              this.startDownloading();
              this._closeDialog("Download");
            }
          );
        })
        .catch(function (err) {
          alert(err);
        });
      this.LikeDownloadTracker(this.state.DetailedViewItem.Id, "Download");
    } else {
      this.startDownloading();
      this._closeDialog("Download");
    }
  };

  private LikeDownloadTracker(solutionId: any, clickType: string) {
    let submitData = null;
    let tempDetailView = this.state.DetailedViewItem;
    if (clickType === "View") {
      let tempviews = JSON.parse(this.state.DetailedViewItem.Views || "[]");
      tempviews.push({ email: this.currentuseremail });
      submitData = {
        ViewsCount: tempviews.length,
        Views: JSON.stringify(tempviews),
      };
      tempDetailView.ViewsCount = tempviews.length;
      tempDetailView.Views = tempviews;
      this.setState({
        DetailedViewItem: tempDetailView,
      });
    }
    if (clickType === "Download") {
      let tempDownloads = JSON.parse(
        this.state.DetailedViewItem.Downloads || "[]"
      );
      tempDownloads.push({ email: this.currentuseremail });
      submitData = {
        DownloadsCount: tempDownloads.length,
        Downloads: JSON.stringify(tempDownloads),
      };
      tempDetailView.DownloadsCount = tempDownloads.length;
      tempDetailView.Downloads = tempDownloads;
      this.setState({
        DetailedViewItem: tempDetailView,
      });
    }
    if (clickType === "Like") {
      if (this.state.userLiked === false) {
        let tempLikes = JSON.parse(this.state.DetailedViewItem.Likes || "[]");
        tempLikes.push({ email: this.currentuseremail });
        submitData = {
          LikesCount: tempLikes.length,
          Likes: JSON.stringify(tempLikes),
        };
        tempDetailView.LikesCount = tempLikes.length;
        tempDetailView.Likes = tempLikes;
        this.setState({
          userLiked: true,
          DetailedViewItem: tempDetailView,
        });
      }
    }
    if (submitData) {
      let webitem = new Web(
        this.props.context.pageContext.web.absoluteUrl
      ).lists
        .getByTitle("Automation Rack")
        .items.getById(solutionId);
      webitem.update(submitData).catch((error) => {
        console.log(error);
      });
    }
  }

  startDownloading() {
    this.state.DownloadAttachments.map((attachment, index) => {
      let iframe = document.createElement("iframe");
      iframe.style.visibility = "collapse";
      document.body.appendChild(iframe);
      var downloadAttachmentUrl =
        this.props.context.pageContext.web.serverRelativeUrl +
        "/_layouts/download.aspx";
      iframe.contentDocument.write(
        `<form action="${downloadAttachmentUrl}" method="GET">
                        <input name="SourceUrl" id="SourceUrl" value="${attachment.ServerRelativeUrl.replace(
                          /\"/g,
                          '"'
                        )}">
                   </form>`
      );
      iframe.contentDocument.forms[0].submit();

      setTimeout(() => iframe.remove(), 2000);
    });
  }

  onBackClick = (
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>
  ): void => {
    this.props.onBackLinkClick(this.state.DetailedViewItem);
  };

  openDownloadDialog = (
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>
  ): void => {
    this.setState((prevState) => ({
      DownloadDialog: !prevState.DownloadDialog,
    }));
  };

  private _closeDialog = (type): void => {
    if (type == "Download") {
      this.setState((prevState) => ({
        DownloadDialog: !prevState.DownloadDialog,
        ClickDownloadAttachments: false,
        AcknowledgeCheckBoxState: !prevState.AcknowledgeCheckBoxState,
      }));
    }
  };

  RenderErrorDialog(DialogConfig: any): React.ReactNode {
    return (
      <Dialog
        hidden={!this.state.ShowDialog}
        onDismiss={this._closeErrorDialog.bind(this, DialogConfig.title)}
        dialogContentProps={{
          type: DialogType.normal,
          title: DialogConfig.title,
          closeButtonAriaLabel: "Close",
          subText: DialogConfig.subtext,
        }}
        modalProps={{
          isBlocking: false,
          styles: {
            main: { maxWidth: "500px !important", width: "100% !important" },
          },
        }}
      >
        <DialogFooter>
          <DefaultButton
            className="btn-yellow"
            onClick={this._closeErrorDialog.bind(this, DialogConfig.title)}
            text="Ok"
          />
        </DialogFooter>
      </Dialog>
    );
  }

  private _closeErrorDialog = (type): void => {
    this.setState((prevState) => ({
      ShowDialog: {
        // object that we want to update
        ...prevState.ShowDialog, // keep all other key-value pairs
        show: !prevState.ShowDialog.show, // update the value of specific key
      },
    }));
  };

  CallSuccessOrFail(SubmitStatus: string, dialogType: string) {
    if (SubmitStatus == "Fail") {
      this.setState((prevState) => ({
        ShowDialog: {
          // object that we want to update
          ...prevState.ShowDialog, // keep all other key-value pairs
          show: !prevState.ShowDialog.show, // update the value of specific key
          title: "Fail",
          subtext: "Failed to Submit",
        },
        Errors: [],
      }));
    } else if (SubmitStatus == "Success") {
      this.setState((prevState) => ({
        ShowDialog: {
          // object that we want to update
          ...prevState.ShowDialog, // keep all other key-value pairs
          show: !prevState.ShowDialog.show, // update the value of specific key
          title: "Success",
          subtext: "Submitted Successfully",
        },
        Errors: [],
      }));
    }
    //closing parent dialog after submission success or fail
    this._closeDialog(dialogType);
  }
}
