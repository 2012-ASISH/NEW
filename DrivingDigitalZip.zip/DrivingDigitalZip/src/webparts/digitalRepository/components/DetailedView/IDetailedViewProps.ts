import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "@microsoft/sp-http";
import { IGDSSolutionItem } from "../../Model/ISolutionDetails";

export interface IDetailedViewProps {
  context: WebPartContext;
  spHttpClient: SPHttpClient;
  ViewDetailedItem: IGDSSolutionItem;
  onBackLinkClick: any;
  subServiceLines: any;
  absoluteUrl: string;
}
