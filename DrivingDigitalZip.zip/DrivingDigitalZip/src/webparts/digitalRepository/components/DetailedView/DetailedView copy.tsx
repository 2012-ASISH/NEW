import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as constants from '../../constants';
import { IDetailedViewProps } from './IDetailedViewProps';
import { IDetailedViewState } from './IDetailedViewState';
import { GDSSpinner } from '../FabricUiComponents/GDSSpinner';
import { GDSService } from '../../Service/GDSService';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { GDSCheckbox } from '../FabricUiComponents/GDSCheckbox';
import { GDSTextField } from '../FabricUiComponents/GDSTextField';
import { IGDSReportBugItem, IGDSSuggestionItem } from '../../Model/ISolutionDetails';
import pnp, { AttachmentFileInfo, Web } from 'sp-pnp-js';
import { GDSFrame } from '../SubmitSolutionHeader/GDSFrame';

export class DetailedView extends React.Component<IDetailedViewProps, IDetailedViewState> {




    constructor(props) {
        super(props);
        this.state = {
            DetailedViewItem: this.props.ViewDetailedItem,
            ReportDialog: false,
            EnhancementsDialog: false,
            ViewMoreUsersDialog: false,
            DownloadDialog: false,          

            SubmitReportBugDetails: this.reportBugItem,
            SubmitEnhanceFeatureDetails: this.featureEnhanceItem,
            DownloadAttachments: [],
            ClickDownloadAttachments: false,

            Errors: [],
            ShowErrors: false,
            ShowDialog: {
                show: false,
                title: '',
                subtext: ''
            },

            AcknowledgeCheckBoxState: false,
            TrackLikesData: this.props.TrackLikesItem
        }
    }

    public componentDidMount() {
        
    }

    public render() {
        return (
            <div>{this.RenderForm()}</div>
        )
    }

    RenderForm(): React.ReactNode {
        return (
            <div>
                <div className="solution-details">{this.RenderViewForm()}</div>
            </div>
        )
    }






    RenderViewForm(): React.ReactNode {
        return this.state.DetailedViewItem.map((solution, index) => {
            //var areaStampImageName = this.getAreaStampImageName(solution.GDSAreaCertified);     
            return (<div>
                <div className="create-sol-form-header">
                    <div className="row">
                        <div className="col-md-6">
                            <a className="back-link" onClick={this.onBackClick.bind(this)}><i className="fa fa-arrow-left"></i> Back</a>
                            <div className="create-sol-form-header-title"><h2>{solution.Title}</h2></div>
                        </div>
                        <div className="col-md-6">
                            <p>
                                <span>
                                    Last updated date
                                </span>
                                {GDSService.getDateFormat(solution.Modified)}
                            </p>
                        </div>
                    </div>
                </div>
                <div className="create-sol-form-body mt-1">
                    <div className="row">
                        <div className="col-md-8">
                            <div className="row">
                                <div className="col-md-12">
                                    <p><span>Technology  :  </span><b>{solution.Technology}</b> | <span>Sector :   </span><b>{solution.SubServiceLine1}</b> | <span>Area :  </span><b>{solution.Area}</b></p>
                                    <p>{solution.GDSSolutionDescription}</p>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">
                                    <h4>Solutions support</h4>
                                    <ul className="sol-owner">
                                        <li>
                                            <div className="user-img-2"><img src={constants.SPFXConstants.Constants.UserPhotoUrlSize + solution.SolutionOwner["UserName"]} /></div>
                                            <div className="user-name">
                                                <p>{solution.SolutionOwner["Title"]}</p>
                                                <span>Solution owner</span>
                                            </div>
                                        </li>
                                    </ul>
                                    {/* <ul className="sol-contri">
                                        {
                                            solution.GDSSolutionContributors.map((user, index) => {
                                                if(index < 2)
                                                {
                                                    return <li>
                                                        <div className="user-img-2"><img src={constants.SPFXConstants.Constants.UserPhotoUrlSize + user["UserName"]} /></div>
                                                        <div className="user-name">
                                                            <p>{user["Title"]}</p>
                                                            <span>Solution contributor</span>
                                                        </div>
                                                    </li>
                                                }
                                            })
                                        }
                                        {solution.GDSSolutionContributors.length > 2 && <li onClick={this.openViewMoreUsers.bind(this)}>
                                            <div className="user-img-2"><a>+{solution.GDSSolutionContributors.length - 2}</a></div>
                                            <div className="user-name">
                                                <a>View more</a>
                                            </div>
                                        </li>}
                                    </ul> */}
                                </div>
                            </div>
                        </div>
                        {/* <div className="col-md-4">
                            <div className="certificate">
                                <div className="cert-img">                                   
                                    <img src={constants.SPFXConstants.Constants.imagesPath + areaStampImageName} />
                                </div>
                                <div className="cert-det">
                                        <h4>Approved for</h4>
                                        <p><h4>{GDSService.formatSolutionColumnValue(solution.GDSRegionalGeography)}</h4></p>
                                </div>
                            </div>
                        </div> */}
                    </div>
                    {/* <div className="row">
                        <div className="col-md-12">
                            <a href="" className="yammer">
                                <img src={constants.SPFXConstants.Constants.imagesPath + "Asset_16.png"} />
                                <span>Get help from the expert network on Yammer</span>
                            </a>
                        </div>
                    </div> */}
                    <div className="row mt-1">  
                        <div className="col-md-9">
                            {/* <button className="btn btn-bug mr" onClick={this.openReportBugDialog.bind(this)}><i className="fa fa-exclamation-triangle"></i> Report a bug or defect</button>
                            <button className="btn btn-suggest" onClick={this.openEnhancementsDialog.bind(this)}><i className="fa fa-hand-holding"></i> Suggest features or improvements</button> */}
                        </div>
                        <div className="col-md-3">                        
                            {/* <button className={`btn btn-${GDSService.getSolutionLikeColorClassName(this.state.TrackLikesData, solution.GDSSolutionID, this.props['GDSLoggedInUser'][0].Email)} mr`} onClick={this.onLikeClick.bind(this, solution.GDSSolutionID, solution.GDSName)}><i className="fa fa-thumbs-up"></i> {GDSService.getSolutionLikeCount(this.state.TrackLikesData, solution.GDSSolutionID)}</button> */}
                            <button className="btn btn-yellow" onClick={this.openDownloadDialog.bind(this)}><i className="fa fa-download"></i> Download</button>
                        </div>
                    </div>
                </div>
            </div>)
        });
    }

    getAreaStampImageName(GDSAreaCertified: string) {
        switch(GDSAreaCertified.toLowerCase())
        {
            case constants.SPFXConstants.Constants.Area_Americas: return "Americas.png";
            case constants.SPFXConstants.Constants.Area_Asiapac: return "AsiaPac.png";
            case constants.SPFXConstants.Constants.Area_Emeia: return "EMEIA.png";            
        }
    }

    onLikeClick = (solutionId: string, solutionName: string, event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void =>  {
        event.stopPropagation();
        this.LikeDownloadTracker(solutionId, solutionName, "Like");
     }
    
    DownloadAttachments = (itemId: any, event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {        
        this.LikeDownloadTracker(this.state.DetailedViewItem[0].Id, this.state.DetailedViewItem[0].Title, "Download");
        //var itemByID = pnp.sp.web.getList(this.props.context.pageContext.web.serverRelativeUrl + constants.SPFXConstants.Constants.GDSMarketplaceListUrl).items.getById(itemId);        
        if(this.state.DownloadAttachments.length == 0)
        {
            let web = new Web(this.props.context.pageContext.web.absoluteUrl);
            var itemByID = web.getList(this.props.context.pageContext.web.serverRelativeUrl + constants.SPFXConstants.Constants.GDSMarketplaceListUrl).items.getById(itemId);
            itemByID.attachmentFiles.get().then(attachmentArray => {
                this.setState((prevState) => ({
                    DownloadAttachments: attachmentArray                   
                }));
            }).catch(function (err) {
                alert(err);
            });
            // this.LikeDownloadTracker(this.state.DetailedViewItem[0].GDSSolutionID, this.state.DetailedViewItem[0].GDSName, "Download");
        }
        // else{
        //     this.setState({                
        //         ClickDownloadAttachments: true
        //     });           
        // }        
    }

    private LikeDownloadTracker(solutionId: string, solutionName: string, clickType:string) {
        
        var loggedInUserEmail = this.props["GDSLoggedInUser"][0].Email;
        GDSService.clickLikesDownloadCount(solutionId, solutionName, loggedInUserEmail, clickType, this.props.context.pageContext.web.absoluteUrl, this.props.context.pageContext.web.serverRelativeUrl, this.props.spHttpClient)
            .then((submitLikesTracker) => {
                if(submitLikesTracker == 'UserAlreadyLiked')
                {
                  
                }
                else if (submitLikesTracker != -1) {
                    console.log("Success");
                    var tempTrackLikes = this.state.TrackLikesData;
                    var index = this.state.TrackLikesData.map(x => { return x.id; }).indexOf(solutionId);
                    //New item to be created in tracker list to track likes
                    if (index === -1) {
                        tempTrackLikes.push(submitLikesTracker);
                    }
                    else {                        
                        // tempTrackLikes[index].GDSTrackLikes = submitLikesTracker.GDSTrackLikes;
                        // tempTrackLikes[index].GDSDownloads = submitLikesTracker.GDSDownloads; 
                        tempTrackLikes[index] = submitLikesTracker;                       
                    }

                    if (clickType.toLowerCase() == "like") {
                        this.setState({
                            TrackLikesData: tempTrackLikes
                        });
                    }
                    else if(clickType.toLowerCase() == "download"){
                        this.setState({
                            TrackLikesData: tempTrackLikes,
                            ClickDownloadAttachments: true
                        });                            
                    }
                }
                else {
                    console.log("Fail");
                }
            });
    }

    startDownloading(): React.ReactNode {
        return this.state.DownloadAttachments.map((attachment, index) => {            
					// let a = document.createElement('a');
					// a.href = attachment.ServerRelativeUrl;
                    // a.download = attachment.FileName;
                    // // var NameToDownload = "desired name here";
                    // // a.innerHTML=NameToDownload;
                    // a.click();
                //return <GDSFrame iframeSrc={attachment.ServerRelativeUrl} />
                
                let iframe = document.createElement('iframe');
                iframe.style.visibility = 'collapse';
            // document.body.append(iframe);
                document.body.appendChild(iframe);
                //`<form action="${attachment.ServerRelativeUrl.replace(/\"/g, '"')}" method="GET"></form>`
                
                var downloadAttachmentUrl = this.props.context.pageContext.web.serverRelativeUrl + "/_layouts/download.aspx";
                //this.props.context.pageContext.web.serverRelativeUrl + "/_layouts/download.aspx?SourceUrl=" + attachment.ServerRelativeUrl.replace(/\"/g, '"') + "&embedded=true";
                iframe.contentDocument.write(                   
                   `<form action="${downloadAttachmentUrl}" method="GET">
                        <input name="SourceUrl" id="SourceUrl" value="${attachment.ServerRelativeUrl.replace(/\"/g, '"')}">
                   </form>`
                );
                iframe.contentDocument.forms[0].submit();

                setTimeout(() => iframe.remove(), 2000);
        });      
    }

    openViewMoreUsers = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {
        this.setState((prevState) => ({ 
            ViewMoreUsersDialog: !prevState.ViewMoreUsersDialog
        }));
    }

    onBackClick = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {
        // this.props.onBackLinkClick("hideDetailedViewForm");
        this.props.onBackLinkClick(this.state.TrackLikesData);
    }

    openReportBugDialog = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {
        this.setState((prevState) => ({ 
            ReportDialog: !prevState.ReportDialog,
            SubmitReportBugDetails: {                   // object that we want to update
                ...prevState.SubmitReportBugDetails,    // keep all other key-value pairs
                Title: this.props.ViewDetailedItem[0].GDSName,
                Id: this.props.ViewDetailedItem[0].id,
                SolutionOwnerDisplayName: this.props.ViewDetailedItem[0].GDSSolutionOwner.Title,       // update the value of specific key
                SolutionOwnerEmail: this.props.ViewDetailedItem[0].GDSSolutionOwner.UserName
            }
        }));
    }

    openEnhancementsDialog = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {        
        this.setState((prevState) => ({ 
            EnhancementsDialog: !prevState.EnhancementsDialog,
            SubmitEnhanceFeatureDetails: {                   // object that we want to update
                ...prevState.SubmitEnhanceFeatureDetails,    // keep all other key-value pairs
                Title: this.props.ViewDetailedItem[0].GDSName,
                id: this.props.ViewDetailedItem[0].id,       // update the value of specific key
                SolutionOwnerDisplayName: this.props.ViewDetailedItem[0].GDSSolutionOwner.Title
            }
        }));
    }

    openDownloadDialog = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {        
        this.setState((prevState) => ({ 
            DownloadDialog: !prevState.DownloadDialog
        }));
    }
    
    private _closeDialog = (type): void => {
        if (type == "Bug") {
            this.setState((prevState) =>
                ({ 
                    ReportDialog: !prevState.ReportDialog,
                    SubmitReportBugDetails: this.reportBugItem,
                    Errors:[]
                }));
        }
        else if(type == "Enhance"){
            this.setState((prevState) =>
                ({ 
                    EnhancementsDialog: !prevState.EnhancementsDialog,
                    SubmitEnhanceFeatureDetails: this.featureEnhanceItem,
                    Errors:[]
                }));
        }
        else if(type == "User"){
            this.setState((prevState) =>
                ({ ViewMoreUsersDialog: !prevState.ViewMoreUsersDialog })); 
        }
        else if(type == "Download"){
            this.setState((prevState) =>
                ({ 
                    DownloadDialog: !prevState.DownloadDialog,
                    ClickDownloadAttachments: false,
                    AcknowledgeCheckBoxState: !prevState.AcknowledgeCheckBoxState
                })); 
        }        
    }

    RenderErrorDialog(DialogConfig: any): React.ReactNode {
        return <Dialog
            hidden={!this.state.ShowDialog}
            onDismiss={this._closeErrorDialog.bind(this, DialogConfig.title)}
            dialogContentProps={{
                type: DialogType.normal,
                title: DialogConfig.title,
                closeButtonAriaLabel: 'Close',
                subText: DialogConfig.subtext
            }}
            modalProps={{
                isBlocking: false,
                styles: { main: { maxWidth: '500px !important', width: '100% !important' } }
            }}
        >
            <DialogFooter>
                <DefaultButton className="btn-yellow" onClick={this._closeErrorDialog.bind(this, DialogConfig.title)} text="Ok" />                
            </DialogFooter>
           
        </Dialog>
    }
  
     private _closeErrorDialog = (type): void => {
        this.setState((prevState) =>
           ({
              ShowDialog: {                   // object that we want to update
                 ...prevState.ShowDialog,    // keep all other key-value pairs
                 show: !prevState.ShowDialog.show      // update the value of specific key
              }
           }));        
     }

     CallSuccessOrFail(SubmitStatus: string, dialogType: string) {
        if (SubmitStatus == "Fail") {
           this.setState((prevState) => ({
              ShowDialog: {                   // object that we want to update
                 ...prevState.ShowDialog,    // keep all other key-value pairs
                 show: !prevState.ShowDialog.show,      // update the value of specific key
                 title: 'Fail',
                 subtext: 'Failed to Submit'
              },
              SubmitReportBugDetails: this.reportBugItem,
              SubmitEnhanceFeatureDetails: this.featureEnhanceItem,
              Errors:[]
           }));
        }
        else if (SubmitStatus == "Success")
        {
           this.setState((prevState) => ({
              ShowDialog: {                   // object that we want to update
                 ...prevState.ShowDialog,    // keep all other key-value pairs
                 show: !prevState.ShowDialog.show,      // update the value of specific key
                 title: 'Success',
                 subtext: 'Submitted Successfully'
              },
              SubmitReportBugDetails: this.reportBugItem,
              SubmitEnhanceFeatureDetails: this.featureEnhanceItem,
              Errors:[]
           }));
        }
        //closing parent dialog after submission success or fail
        this._closeDialog(dialogType);
     }
}