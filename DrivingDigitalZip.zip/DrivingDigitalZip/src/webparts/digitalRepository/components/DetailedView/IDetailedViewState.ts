import { IGDSSolutionItem } from "../../Model/ISolutionDetails";

export interface IDetailedViewState {
  DetailedViewItem: IGDSSolutionItem;
  DownloadDialog: boolean;
  DownloadAttachments: any[];
  ClickDownloadAttachments: boolean;

  Errors: any[];
  ShowErrors: boolean;
  ShowDialog: {
    show: boolean,
    title: string,
    subtext: string
  },
  Attachments: {
    FileName: string;
    ServerRelativeUrl: string;
  }[];

  AcknowledgeCheckBoxState: boolean;
  TrackLikesData: any[];
  userLiked: boolean;
  SliderImages:any[];
}