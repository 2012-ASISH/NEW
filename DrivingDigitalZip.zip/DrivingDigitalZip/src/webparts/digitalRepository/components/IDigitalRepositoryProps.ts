import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient } from "@microsoft/sp-http";

export interface IDigitalRepositoryProps {
  description: string;
  context: WebPartContext;
  spHttpClient: SPHttpClient;
  absoluteUrl: string;
}
