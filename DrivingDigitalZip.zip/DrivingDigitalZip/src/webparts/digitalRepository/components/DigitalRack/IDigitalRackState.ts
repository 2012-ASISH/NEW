import { IDropdownOption } from "office-ui-fabric-react";
import { IdigitalRackDropdown, IGDSDropDownStruct, IGDSSolutionItem } from "../../Model/ISolutionDetails";

export interface IDigitalRackState {
  DownloadDialog: boolean;
  
  CSSLoaded: boolean;
  SolutionDetails: IGDSSolutionItem[];
  FilteredSolutionDetails: IGDSSolutionItem[];
  FilteredDataLoaded: boolean;
  // LoggedInUserSolutions: any[];
  // GDSRegionDropDown: IGDSDropDownStruct[];
  // GDSRegionList: IGDSDropDownStruct[];
  // ShowSubmitForm: boolean;
  FilterQuery: {
    Area: string[];
    Technology: string[];
    SubServiceLine1: string[];
    //GDSSolutionType: string[];
    GDSLocation: string[];
    Category: string[];
    CertificationType: string[];
    CertificationFor:string[];
   
  };
  DropdownOptions:IdigitalRackDropdown,
  AuditPhaseOptions:string[],

  RequestTagsValue:string[];
  AuditTagsValue:string[];
  ViewDetailedSolution: IGDSSolutionItem;
  ShowDetailedViewForm: boolean;
  ShowBadgeColor: string;

  PaginationPreviousCSS: string;
  PaginationNextCSS: string;
  PaginationCurrentCSS: string;
  PaginationCurrentPage: number;

  TrackLikesData: any[];
  LikeCount: number;
  Area: any;
  SubServiceLine1: any;
  Technology: any;
  GDSLocation: any;
  Category: any;
  ShowWarning: boolean;
  selectedFilterCard: string;
  AuditPhase:string;
  RequestTags:string;
  SearchText:string;
  SearchToggle:boolean;
  CertificationType:any;
  CertificationFor:any;
}