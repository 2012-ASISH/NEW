import * as React from "react";
import { SPComponentLoader } from "@microsoft/sp-loader";
import * as constants from "../../constants";
import { IDigitalRackProps } from "./IDigitalRackProps";
import { IDigitalRackState } from "./IDigitalRackState";
import { GDSSpinner } from "../FabricUiComponents/GDSSpinner";
import { GDSDropDown } from "../FabricUiComponents/GDSDropDown";
import { Image } from "office-ui-fabric-react/lib/Image";
import {
  Dialog,
  DialogFooter,
  DialogType,
  IconButton,
  SearchBox,
  Toggle,
} from "office-ui-fabric-react";
import { DetailedView } from "../DetailedView/DetailedView";
import { DefaultButton, PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { IGDSSolutionItem } from "../../Model/ISolutionDetails";
import { GDSService } from "../../Service/GDSService";
import { sp } from "@pnp/sp";
import { Web } from "sp-pnp-js";
import styles from "../DigitalRack/DigitalRack.module.scss";
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import {
  getTheme,
  createTheme,
  ITheme,
} from "office-ui-fabric-react/lib/Styling";
import Select from "react-select";

const modalPropsStyles = { main: { minWidth: 600 } };

const modalProps = {
  isBlocking: true,
  styles: modalPropsStyles,
};
export class DigitalRack extends React.Component<
  IDigitalRackProps,
  IDigitalRackState
> {
  private customTheme: ITheme;
  private gdsService: GDSService = new GDSService();
  constructor(props) {
    super(props);
    this.customTheme = createTheme(getTheme());
    this.customTheme.semanticColors.bodySubtext = "#ffe600";
    this.customTheme.semanticColors.bodyTextChecked = "#ffe600";
   
    this.state = {
      DownloadDialog: false,
      SearchToggle:false,
      CSSLoaded: true,
      SolutionDetails: [],
      FilteredSolutionDetails: [],
      FilteredDataLoaded: false,
      ViewDetailedSolution: null,
      ShowDetailedViewForm: false,
      ShowBadgeColor: "",
      PaginationCurrentCSS: "active",
      PaginationNextCSS: "",
      PaginationPreviousCSS: "disabled",
      PaginationCurrentPage: 1,
      TrackLikesData: [],
      LikeCount: 0,
      ShowWarning: false,
      selectedFilterCard: "",
      DropdownOptions: {
        RequestTags: []
      },
      RequestTagsValue: [],
      AuditTagsValue:[],
      AuditPhase: "",
      RequestTags: "",
      AuditPhaseOptions: [],
      SearchText: "",
      SubServiceLine1: [
        { key: "ALL", text: "ALL" },
        { key: "Core Audit", text: "Core Audit" },
        { key: "AMS", text: "AMS" },
        { key: "AQS", text: "AQS" },
        { key: "FAAS", text: "FAAS" },
        { key: "FIS", text: "FIS" },
        { key: "DA-Digital", text: "DA-Digital" },
        { key: "Operations", text: "Operations" },
      ],

      Area: [
        { key: "ALL", text: "ALL" },
        { key: "Americas", text: "Americas" },
        { key: "EMEIA", text: "EMEIA" },
        { key: "APAC", text: "APAC" },
        { key: "Global", text: "Global" },
      ],

      Technology: [
        { key: "ALL", text: "ALL" },
        { key: "RPA", text: "RPA" },
        { key: ".Net", text: ".Net" },
        { key: "Web Application", text: "Web Application" },
        { key: "Python", text: "Python" },
        { key: "VBA/Macro", text: "VBA/Macro" },
        { key: "PowerBI", text: "PowerBI" },
        { key: "Power Automate", text: "Power Automate" },
        { key: "SharePoint", text: "SharePoint" },
        { key: "Alteryx", text: "Alteryx" },
        { key: "AI/ML", text: "AI/ML" },
        { key: "Others", text: "Others" },
      ],
      GDSLocation: [
        { key: "ALL", text: "ALL" },
        { key: "India", text: "India" },
        { key: "China", text: "China" },
        { key: "Philippines", text: "Philippines" },
      ],
      Category: [
        { key: "ALL", text: "ALL" },
        { key: "Commercial", text: "Commercial" },
        { key: "FSO", text: "FSO" },
      ],
      CertificationType: [
        { key: "ALL", text: "ALL" },
        { key: "Not Certified", text: "Not Certified" },
        { key: "Regional Certified", text: "Regional Certified" },
        { key: "Global Certified", text: "Global Certified" },
      ],
      CertificationFor: [{ key: "ALL", text: "ALL" },
      { key: "NA", text: "NA" },
      { key: "Global Use", text: "Global Use" },
      { key: "Regional Use", text: "Regional Use" },
      { key: "GDS Use", text: "GDS Use" },],

        FilterQuery: {
        Area: [],
        Technology: [],
        SubServiceLine1: [],
        //MSMSolutionType: [],
        GDSLocation: [],
        Category: [],
        CertificationType:[],
        CertificationFor: [],
      },
      
    };
    sp.setup({
      spfxContext: this.props.context,
    });
    this.loadCSS();
   
    //this.getvalue();
  }

  public componentDidMount() {
    this.setState({
      CSSLoaded: true,
    });

    this.checkForToolId();
    this.getRequestTags();
    this.getAuditPhaseTags();
    //this.getDropdownOptions(constants.SPFXConstants.ListNames.RegionMapping, "CertificationFor");
   
  }

  // private getDropdownOptions(listName: string, propertyName: string) {
  //   try {
  //     let restUrl: string = String.Format(
  //       constants.SPFXConstants.API.ListItems,
  //       this.props.absoluteUrl,
  //       listName
  //     );
  //     let selectQuery: string = String.Format(
  //       constants.SPFXConstants.API.SelectQuery,
  //       "Id,Title"
  //     );
  //     let topQuery: string = String.Format(constants.SPFXConstants.API.TopQuery, "1000");
  //     this.gdsService
  //       .getDropdownOptions(restUrl + selectQuery + topQuery, this.props.spHttpClient)
  //       .then((options) => {
  //        //this.state.FilterQuery[propertyName] = options;
  //         this.setState({ CertificationFor: options });
  //       });
  //   } catch (ex) {
      
  //   }
  // }

  private getRequestTags() {
    let ddOptions = {};
     sp.web.lists
      .getByTitle("Automation Rack")
      .fields.getByInternalNameOrTitle("RequestTags")()
      .then((field) => {
        ddOptions["RequestTags"] = [];
        field["Choices"].map((choice) => {
          ddOptions["RequestTags"].push({ 
            value: choice,
            label: choice,
          });
        });
        this.setState({ DropdownOptions: ddOptions });
      });
  }
  private getAuditPhaseTags() {
    let AuditPhaseOptions = [];
    sp.web.lists
      .getByTitle("Automation Rack")
      .fields.getByInternalNameOrTitle("AuditPhase")()
      .then((field) => {
        field["Choices"].map((choice) => {
          AuditPhaseOptions.push(choice);
        });
        this.setState({ AuditPhaseOptions: AuditPhaseOptions });
      });
  }

  private checkForToolId() {
    let urlID: number = Number(this.props.routerContext.match.params.Id);
    try {
      if (!isNaN(urlID)) {
        this.getToolById(urlID);
      } else {
        this.getTools();
      }
    } catch {}
  }

  private getToolById(id: number) {
    let web = new Web(this.props.context.pageContext.web.absoluteUrl);

    web.lists
      .getByTitle("Automation Rack")
      .items.getById(id)
      .select(
        "Id",
        "Title",
        "SolutionOwner/Title",
        "SolutionOwner/EMail",
        "SolutionOwner/Id",
        "SolutionDescription",
        "Technology",
        "SubServiceLine1",
        "Category",
        "SPOC/EMail",
        "SPOC/Title",
        "SPOC/Id",
        "Reusability",
        "GoLive",
        "GDSLocation",
        "BusinessProblem",
        "Area",
        "Status",
        "Created",
        "Modified",
        "ProjectImage",
        "ViewsCount",
        "DownloadsCount",
        "LikesCount",
        "Likes",
        "Views",
        "Downloads",
        "AuditPhase",
        "RequestTags",
        "DemoVideoLink",
        "CertificationType",
        "CertifiedFor",
        "CertifiedRegion/Title",
        "SolutionRequireForm114Usage",
        "EstSavingsPerEngagementInHours"
        
      )
      .expand("SolutionOwner, SPOC,CertifiedRegion")
      .get()
      .then((item) => {
        this.setState({
          ViewDetailedSolution: item,
          FilteredDataLoaded: true,
          ShowDetailedViewForm: true,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }

  getTools = () => {
    let web = new Web(this.props.context.pageContext.web.absoluteUrl);

    web.lists
      .getByTitle("Automation Rack")
      .items.select(
        "Id",
        "Title",
        "SolutionOwner/Title",
        "SolutionOwner/EMail",
        "SolutionOwner/Id",
        "SolutionDescription",
        "Technology",
        "SubServiceLine1",
        "Category",
        "SPOC/EMail",
        "SPOC/Title",
        "SPOC/Id",
        "Reusability",
        "GoLive",
        "GDSLocation",
        "BusinessProblem",
        "Area",
        "Status",
        "Created",
        "Modified",
        "ProjectImage",
        "ViewsCount",
        "DownloadsCount",
        "LikesCount",
        "Likes",
        "Views",
        "Downloads",
        "AuditPhase",
        "RequestTags",
        "DemoVideoLink",
        "CertificationType",
        "CertifiedFor",
        "CertifiedRegion/Title",
        "SolutionRequireForm114Usage",
        "EstSavingsPerEngagementInHours"
        
      )
      .filter("Status eq 'Certified'")
      .expand("SolutionOwner, SPOC,CertifiedRegion")
      .orderBy("ViewsCount", false)
      .top(2000)
      .get()
      .then((items) => {
        //Image response is coming as JSON to convert we are parsing it to object and pushing again back to items.
        // items.map(eachitem => {
        //    eachitem.ProjectImage = JSON.parse(eachitem.ProjectImage);
        // });
        this.setState({
          SolutionDetails: items,
          FilteredSolutionDetails: items,
          FilteredDataLoaded: true,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  public render() {
    return (
      <div>
        {
          <div style={{ margin: "0 -25px" }}>
            {this.state.ShowDetailedViewForm ? (
              <div>{this.RenderDetailedViewForm()}</div>
            ) : (
              <div>
                {/* {this.RenderSlider()} */}

                {/* {window.sessionStorage.getItem("ShowPopup")=="true" ? this.RenderMessageBar():null} */}
                {/* {this.state.ShowWarning &&  */}
                {/* {window.sessionStorage.getItem("ShowPopup")=="false" && this.RenderTopFilterControls()} */}
                {this.RenderTopFilterControls()}
                <div id="cardslist" style={{ paddingTop: "2%" }}>
                  {/* {window.sessionStorage.getItem("ShowPopup")=="false" && this.RenderLeftFilterControls()}
                  {window.sessionStorage.getItem("ShowPopup")=="false" && this.RenderSolutions()} */}
                  {this.RenderLeftFilterControls()}
                  {this.RenderSolutions()}
                </div>
              </div>
            )}
          </div>

          // <div>Hello World</div>
        }
      </div>
    );
  }
  changeAreaDrpDwnHandler(value): any {
    this.setState({
      FilteredDataLoaded: false,
    });
    //this.setRegionDropDown(value);
    this.getFilterSolutionListItems(
      constants.SPFXConstants.Constants.areaFilter,
      value.text
    );
  }

  // getvalue(): void {
  //  this.getTools()
  // }
  //-----------------------------------------------------
  // RenderMessageBar(): React.ReactNode {
  //   return (
  //     <Dialog
  //       hidden={window.sessionStorage.getItem("ShowPopup") == "true"?false:true}
  //       onDismiss={() => window.sessionStorage.setItem("ShowPopup", "false")}
  //       dialogContentProps={{
  //         type: DialogType.normal,
  //         title:
  //           "The solutions are not globally certified and custom auto tech (Form 114) to be used along with solution",
  //         // subText:
  //         //   "Do you want to send this message without a subject?",
  //       }}
  //       modalProps={modalProps}
  //     >
  //       <DialogFooter>
  //         <DefaultButton
  //           onClick={() => {
  //             window.sessionStorage.setItem("ShowPopup", "false");
  //             this.setState({CSSLoaded:true})
  //           }}
  //           text="OK"
  //         />
  //       </DialogFooter>
  //     </Dialog>
  //   );
  // }

  //-------------------------Slider----------------------------

  //   RenderSlider(): React.ReactNode {
  //    let settings = {
  //      dots: false,
  //      infinite: true,
  //      speed: 500,
  //      slidesToShow: 1,
  //      slidesToScroll: 1,

  //    };
  //    return (

  //      <div className="solutions">
  //        <div className="row mb-22">
  //          <div className="col-md-12">
  //            <div className={styles.carousel}>
  //              <Slider {...settings}>
  // {/* //                 */}

  // {this.state.SolutionDetails.slice(0,9).map(solution=>
  //                <div className={styles.carouselblock}>

  //                  <div
  //                    className="ms-Grid-col ms-sm5 ms-md5 ms-lg5"
  //                    style={{ padding: "0" }}
  //                  >
  //                    <img
  //                      className={styles.DASHIMG}
  //                      src={solution.ProjectImage["Url"]}
  //                    />
  //                  </div>
  //                  <div
  //                    className="ms-Grid-col ms-sm7 ms-md7 ms-lg7"
  //                    style={{ padding: "0" }}
  //                  >
  //                    <div className={styles.sliderTextRow}>
  //                      <h3>{solution.Title}</h3>
  //                    </div>
  //                    <div className={styles.DashContent}>
  //                      <p>
  //                        Technology : {solution.Technology} | Sub service line : {solution.SubServiceLine1}
  //                      </p>
  //                      <p>
  //                       {solution.SolutionDescription}
  //                      </p>
  //                      <div className={styles.dashRating}>
  //                        {/* <Rating
  //                          min={1}
  //                          max={5}
  //                          size={RatingSize.Small}
  //                          rating={3}
  //                          readOnly
  //                          theme={this.customTheme}
  //                        />
  //                        <Icon
  //                          iconName="Contact"
  //                          style={{
  //                            paddingRight: "5px",
  //                            marginTop: "10px",
  //                            marginLeft: "10px",
  //                            float: "left",
  //                          }}
  //                        /> */}

  //                               <IconButton className="IconButton" label={`${solution.DownloadsCount}' Downloads'`} iconProps={constants.SPFXConstants.Constants.donloadButtonIcon} title="Downlaod Solution" ariaLabel="Emoji" disabled={true} />
  //                               <span style={{ padding: '5px 10px 0 0', marginLeft: '-5px', display: 'inline-block', fontSize: '1.1em' }}>{`${solution.DownloadsCount || 0}`}</span>
  //                               <IconButton className="IconButton" iconProps={constants.SPFXConstants.Constants.likeButtonIcon} title="like" ariaLabel="Emoji" disabled={true} />
  //                               <span style={{ padding: '5px 10px 0 0', marginLeft: '-5px', display: 'inline-block', fontSize: '1.1em' }}>{`${solution.LikesCount || 0}`}</span>
  //                               <IconButton className="IconButton" iconProps={constants.SPFXConstants.Constants.viewButtonIcon} title="Views" ariaLabel="Emoji" disabled={true} />
  //                               <span style={{ padding: '5px 10px 0 0', marginLeft: '-5px', display: 'inline-block', fontSize: '1.1em' }}>{`${solution.ViewsCount || 0}`}</span>
  //                         {/* <p className="float-right">20</p> */}
  //                      </div>
  //                      <br />
  //                      <button className="view-sol-form-btn btn-yellow" onClick={() => {
  //                         this.onDetailedViewClick(solution);
  //                         }}>View More</button>
  //                    </div>
  //                  </div>
  //                </div>
  //                )}
  //                {/* <div className={styles.carouselblock}>
  //                  <div
  //                    className="ms-Grid-col ms-sm5 ms-md5 ms-lg5"
  //                    style={{ padding: "0" }}
  //                  >
  //                    <img
  //                      className={styles.DASHIMG}
  //                      src={require("../images/DASHLogo.png")}
  //                    />
  //                  </div>
  //                  <div
  //                    className="ms-Grid-col ms-sm7 ms-md7 ms-lg7"
  //                    style={{ padding: "0" }}
  //                  >
  //                    <div className={styles.sliderTextRow}>
  //                      <h3>Finance Insight</h3>
  //                    </div>
  //                    <div className={styles.DashContent}>
  //                      <p>
  //                        Version : Version | Sector : Sector | Language: Language
  //                      </p>
  //                      <p>
  //                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
  //                        Aenean euismod bibendum laoreet. Proin gravida dolor sit
  //                        amet lacus accumsan et viverra justo commodo. Proin
  //                        sodales pulvinar sic tempor. Sociis natoque penatibus et
  //                        magnis dis parturient montes, nascetur ridiculus mus.
  //                      </p>
  //                      <div className={styles.dashRating}>
  //                        <Rating
  //                          min={1}
  //                          max={5}
  //                          size={RatingSize.Small}
  //                          rating={3}
  //                          readOnly
  //                          theme={this.customTheme}
  //                        />
  //                        <Icon
  //                          iconName="Contact"
  //                          style={{
  //                            paddingRight: "5px",
  //                            marginTop: "10px",
  //                            marginLeft: "10px",
  //                            float: "left",
  //                          }}
  //                        />
  //                        <p className="float-right">20</p>
  //                      </div>
  //                      <br />
  //                      <button className={styles.button}>View More</button>
  //                    </div>
  //                  </div>
  //                </div> */}
  //              </Slider>
  //            </div>
  //          </div>
  //        </div>
  //      </div>
  //    );
  //  }
  //-------------------

  RenderTopFilterControls(): React.ReactNode {
    const customStyles = {
      container:(provided, state)=>{
        const margin = "4.5% 0";
       
        return { ...provided, margin };
      },
      singleValue:(provided, state)=>{
        const color = "#fff";
       
        return { ...provided, color };
      },
      input:(provided, state)=>{
        const color = "#fff";
       
        return { ...provided, color };
      },
      menu: (provided, state) => {
        const backgroundColor = "#2e2e38";
        const alignItems = "normal"
        return { ...provided, backgroundColor,alignItems };
      },
      option: (provided, state) => {
        const backgroundColor = state.isSelected ? '#4a4a4a' : '#2e2e38'
        return { ...provided, backgroundColor };
      },
      control: (provided, state) => {
        const borderRadius = "3px";
        const color = "#fff";
        const marginTop = "5px";
        const backgroundColor = "#2e2e38";
        const minHeight = "45px";
        return { ...provided, borderRadius,color, marginTop,backgroundColor,minHeight };
      },
     
      placeholder: (provided, state) => {
        const color = "#fff";

        return { ...provided, color };
      },
    };
    let filterCards: string[] = this.state.AuditPhaseOptions;
    return this.state.FilteredDataLoaded ? (
      <>
      <div className={styles.headerControl}>
          <label>Search solution by Title</label>
         <Toggle className={styles.headerControlToggle}
            checked={this.state.SearchToggle}
            // disabled={this.state.disableSATForm}
            // onChange={this.handleChange.bind(this,"IsClientLicenced")}
            onChange={(e)=>this.setState({SearchToggle:!this.state.SearchToggle})}
            onText="Tag"
            offText="Tag" 
            />
            </div>
      <div className={styles.topControls}>
        
        <div className={styles.header}>DIGITAL RACK</div>
        {this.state.SearchToggle ? 
        <div className={styles.toptagControls}>
        <Select
        isClearable={true}
        options={this.state.DropdownOptions.RequestTags}
        styles={customStyles}
        theme={(theme) => ({
          ...theme,
          borderRadius: 0,
          colors: {
            ...theme.colors,
            primary25: "grey",
            primary: "#fff",
          },
        })}
        value={{value:this.state.RequestTags,label:this.state.RequestTags}}
        onChange={(selectedOption) =>
          (selectedOption) ?this.setState(
          {
            RequestTags: this.state.RequestTags == selectedOption.value? "" : selectedOption.value,
          }):
          this.setState(
            {
              RequestTags:""
            })
          }
        /></div>:
        // <ListItemPicker listId='0e9d2621-4b7d-4ffd-a009-2eec09ada402'
        // placeholder="Search with tags"
        // columnInternalName='Title'
        // //keyColumnInternalName='Id'
        // className={styles.ListitemPicker}
        // // filter="Title eq 'SPFx'"
        // // orderBy={"Id desc"}
        // itemLimit={5}
        // onSelectedItem={this.onSelectedItem}
        // context={this.props.context} />:
        <SearchBox
        className={styles.search}
        placeholder="Search a tool with title"
        onChange={(val) => {
          this.setState({ SearchText: val });
        }}
        onSearch={() =>
          this.getFilteredSolutionItems({ ...this.state.FilterQuery })
        }
        onClear={() =>
          this.getFilteredSolutionItems({ ...this.state.FilterQuery })
        }
      />}
        
        <label>Filter with audit phase</label>
        <div className={styles.filterCardContainer}>
          {filterCards.map((card) => {
            return (
              <div
                className={
                  this.state.AuditTagsValue.indexOf(card) > -1
                  ? styles.filterCardSelected
                  : styles.filterCard
                }
                onClick={() => {
                  if (this.state.AuditTagsValue.indexOf(card) > -1) {
                    let audittags = this.state.AuditTagsValue;
                    const index = audittags.indexOf(card);
                    audittags.splice(index, 1);
                    if (index > -1) {
                      this.setState(
                        {
                          AuditTagsValue: audittags,
                        })
                      }
                    }else {
                      this.setState(
                        (prevState) => ({
                          AuditTagsValue: [...prevState.AuditTagsValue, card],
                        })
                      );
                    }
                  // this.setState(
                  //   {
                  //     AuditPhase: this.state.AuditPhase == card ? "" : card,
                  //   }
                    // ,
                    // () => {
                    //   this.getFilteredSolutionItems({
                    //     ...this.state.FilterQuery,
                    //   });
                    // }
                 // );
                }}
              >
                {card}
              </div>
              // <div
              //   className={
              //     this.state.AuditPhase == card
              //       ? styles.filterCardSelected
              //       : styles.filterCard
              //   }
              //   onClick={() => {
              //     this.setState(
              //       {
              //         AuditPhase: this.state.AuditPhase == card ? "" : card,
              //       }
              //       // ,
              //       // () => {
              //       //   this.getFilteredSolutionItems({
              //       //     ...this.state.FilterQuery,
              //       //   });
              //       // }
              //     );
              //   }}
              // >
              //   {card}
              // </div>
            );
          })}
        </div>
        {/* <label>Most searched tools</label>
        <div className={styles.SmallfilterCardContainer}>
          {this.state.RequestTagsOptions.map((card) => {
            return (
              <div
                className={
                  this.state.RequestTagsValue.indexOf(card) > -1
                    ? styles.filterCardSelected
                    : styles.filterCard
                }
                onClick={() => {
                  if (this.state.RequestTagsValue.indexOf(card) > -1) {
                    let requesttags = this.state.RequestTagsValue;
                    const index = requesttags.indexOf(card);
                    requesttags.splice(index, 1);
                    if (index > -1) {
                      this.setState(
                        {
                          RequestTagsValue: requesttags,
                        }
                        // ,
                        // () => {
                        //   this.getFilteredSolutionItems({
                        //     ...this.state.FilterQuery,
                        //   });
                        // }
                      );
                    }
                  } else {
                    this.setState(
                      (prevState) => ({
                        RequestTagsValue: [...prevState.RequestTagsValue, card],
                      }),
                      () => {
                        this.getFilteredSolutionItems({
                          ...this.state.FilterQuery,
                        });
                      }
                    );
                  }
                }}
              >
                {card}
              </div>
            );
          })}
        </div> */}
        <div className={styles.SearchButton}><PrimaryButton onClick={()=>  this.getFilteredSolutionItems({ ...this.state.FilterQuery })}>Search</PrimaryButton></div>
      </div>
      </>
    ) : null;
  }

  private scrollToCards() {
    let item = document.getElementById("cardslist");
    item.scrollIntoView({ behavior: "smooth" });
  }

  RenderLeftFilterControls(): React.ReactNode {
    // var areaOptions = {this.state.Area};
    // var SubServiceLineOptions = {this.state.SubServiceLine};
    // var TechnologyOptions = {this.state.Technology};
    //     //sectorOptions.splice(1,1);  //removing 'all' option from the dropdown, added from lookup list
    // var GDSServiceLineOptions = {this.State.GDSServiceLine}; // removing 'All' option from the dropdown

    //  //setting Area Dropdown with loggedin user area value
    //  var areaVal = this.props["LoggedInUserGeographyArea"];
    //  this.changeAreaDrpDwnHandler({key: areaVal, text: areaVal});

    return this.state.FilteredDataLoaded ? (
      <div className={styles.filterCont}>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.Area}
            label="Area"
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            onChange={this.changeDrpDwnHandler.bind(
              this,
              constants.SPFXConstants.Constants.areaFilter
            )}
          />
        </div>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.Technology}
            label="Technology"
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            onChange={this.changeDrpDwnHandler.bind(
              this,
              constants.SPFXConstants.Constants.technologyFilter
            )}
          />
        </div>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.SubServiceLine1}
            label="Sub Service Line"
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            onChange={this.changeDrpDwnHandler.bind(
              this,
              constants.SPFXConstants.Constants.subServiceLineFilter
            )}
          />
        </div>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.Category}
            label="Category"
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            onChange={this.changeDrpDwnHandler.bind(
              this,
              constants.SPFXConstants.Constants.Category
            )}
          />
        </div>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.GDSLocation}
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            label="GDS Location"
            onChange={this.changeDrpDwnHandler.bind(
              this,
              constants.SPFXConstants.Constants.GDSLocationFilter
            )}
          />

          {/* <GDSDropDown options={solutionTypeOptions}
               label="Solution Type"
               onChange={this.changeDrpDwnHandler.bind(this, "MSMApplicableSectorMultiTitles")} 
               //selectedKeys={this.state.SubmitSolutionDetails.MSMApplicableSectorMulti} 
               multiSelect={true}                              
            /> */}
        </div>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.CertificationType}
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            label="Certification Type"
           onChange={this.changeDrpDwnHandler.bind(
              this,
              constants.SPFXConstants.Constants.CertificationType
            )}
          />
        </div>
        <div className={styles.control}>
          <GDSDropDown
            options={this.state.CertificationFor}
            label="Certification For"
            defaultSelectedKey={
              constants.SPFXConstants.Constants.DropDownOptionALL
            }
            onChange={this.changeDrpDwnHandler.bind(
              this,
              "CertificationFor"
            )}
          />
        </div>
      </div>
    ) : null;
  }

  changeSearchTextFieldHandler(value): any {
    // let requestUrl;
    // let web = new Web(this.props.context.pageContext.web.absoluteUrl);
    // if (value != '') {

    this.setState({ SearchText: value }, () => {
      this.getFilteredSolutionItems({ ...this.state.FilterQuery });
    });

    // web.lists.getByTitle("Automation Rack").items
    //    .filter( "Status eq 'Certified' and  substringof('" + value + "',Title)")
    //    .select("Id", "Title", "SolutionOwner/Title", "SolutionOwner/Id", "SolutionDescription", "Technology", "SubServiceLine1", "Category", "SPOC/Title", "SPOC/Id", "Reusability", "GoLive", "GDSLocation", "BusinessProblem", "Area", "Status", "Created", "Modified", "ProjectImage","AuditPhase","RequestTags")
    //    .expand("SolutionOwner, SPOC")
    //    .top(2000)
    //    .get().then((items) => {
    //       //Image response is coming as JSON to convert we are parsing it to object and pushing again back to items.
    //       // items.map(eachitem => {
    //       //    eachitem.ProjectImage = JSON.parse(eachitem.ProjectImage);
    //       // });
    //       this.setState({
    //          FilteredSolutionDetails: items,
    //          PaginationCurrentCSS: 'active',
    //          PaginationNextCSS: '',
    //          PaginationPreviousCSS: 'disabled',
    //          PaginationCurrentPage: 1
    //       })
    //    }).catch(error => { console.log(error) });

    // }
    // else {

    //    web.lists.getByTitle("Automation Rack").items
    //    .select("Id", "Title", "SolutionOwner/Title", "SolutionOwner/EMail", "SolutionOwner/Id", "SolutionDescription", "Technology", "SubServiceLine1", "Category", "SPOC/EMail", "SPOC/Title", "SPOC/Id", "Reusability", "GoLive", "GDSLocation", "BusinessProblem", "Area", "Status", "Created", "Modified", "ProjectImage", "ViewsCount", "DownloadsCount", "LikesCount", "Likes", "Views", "Downloads")
    //    .filter( "Status eq 'Certified'")
    //    .expand("SolutionOwner, SPOC")
    //    .top(2000)
    //    .get().then((items) => {
    //       //Image response is coming as JSON to convert we are parsing it to object and pushing again back to items.
    //       // items.map(eachitem => {
    //       //    eachitem.ProjectImage = JSON.parse(eachitem.ProjectImage);
    //       // });
    //       this.setState({
    //          FilteredSolutionDetails: items,
    //          PaginationCurrentCSS: 'active',
    //          PaginationNextCSS: '',
    //          PaginationPreviousCSS: 'disabled',
    //          PaginationCurrentPage: 1
    //       })
    //    }).catch(error => { console.log(error) });
    // }
  }

  getAuditphaseFilterItems(
    AuditPhaseValue: string[],
    RequestTags?: string,
    SearchText?: string
  ) {
    var results = this.state.SolutionDetails
    if (AuditPhaseValue.length > 0) {
      results = results.filter(
      (e) => (e.AuditPhase && e.AuditPhase.filter((tag) => AuditPhaseValue.indexOf(tag) > -1)
      .length > 0 )
    );
  }

    results = results.filter(
      (e) =>
        SearchText == "" ||
        e.Title.toLowerCase().indexOf(SearchText.toLowerCase()) > -1
    );

    if (RequestTags.length > 0) {
      results = results.filter(
        (sol) =>
          sol.RequestTags &&
          sol.RequestTags.filter((tag) => RequestTags.indexOf(tag) > -1)
            .length > 0
      );

      // results = results.filter((e)=> e.RequestTags.filter( function(e) {
      //    return this.indexOf(e) < 0;
      //  },
      //  RequestTags)
      //   );
      console.log("filtered items" + results);
    }
    this.setState({ AuditTagsValue: AuditPhaseValue });
    // const filterQuery = { ...this.state.FilterQuery }; //JSON.parse(JSON.stringify(this.state.FilterQuery));

    //  this.setState(prevState => ({
    //    FilterQuery: {                   // object that we want to update
    //       ...prevState.FilterQuery,    // keep all other key-value pairs
    //    }
    // }), ()=>{
    // })

    // this.getFilteredSolutionItems(results, filterQuery);

    //  this.setState({
    //    FilteredSolutionDetails: results,
    //    FilteredDataLoaded: true
    //  })
    return results;
  }

  getFilterSolutionListItems(Value: string, filterColumn) {
    let web = new Web(this.props.context.pageContext.web.absoluteUrl);

    web.lists
      .getByTitle("Automation Rack")
      .items.filter(
        filterColumn + " eq '" + Value + "' and Status eq 'Certified'"
      )
      .select(
        "Id",
        "Title",
        "SolutionOwner/Title",
        "SolutionOwner/Id",
        "SolutionDescription",
        "Technology",
        "SubServiceLine1",
        "Category",
        "SPOC/Title",
        "SPOC/Id",
        "Reusability",
        "GoLive",
        "GDSLocation",
        "BusinessProblem",
        "Area",
        "Status",
        "Created",
        "Modified",
        "ProjectImage",
        "AuditPhase",
        "RequestTags",
        "CertificationType",
        "CertifiedRegion/Title",
        "CertifiedFor",
        "ViewsCount",
        "DownloadsCount",
        "LikesCount",
        "Likes",
        "Views",
        "Downloads",
        "SolutionRequireForm114Usage",
        "EstSavingsPerEngagementInHours"
        
      )
      .expand("SolutionOwner, SPOC,CertifiedRegion")
      .top(2000)
      .get()
      .then((items) => {
        //Image response is coming as JSON to convert we are parsing it to object and pushing again back to items.
        // items.map(eachitem => {
        //    eachitem.ProjectImage = JSON.parse(eachitem.ProjectImage);
        // });
        this.setState({
          SolutionDetails: items,
          FilteredSolutionDetails: items,
          FilteredDataLoaded: true,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }

  

  changeDrpDwnHandler(dropDownName, dropdownOpiton): any {
    const filterQuery = { ...this.state.FilterQuery }; //JSON.parse(JSON.stringify(this.state.FilterQuery));
    filterQuery[dropDownName].length = 0;
    filterQuery[dropDownName].push(dropdownOpiton.text);

    this.setState((prevState) => ({
      FilterQuery: {
        // object that we want to update
        ...prevState.FilterQuery, // keep all other key-value pairs
        [dropDownName]: [dropdownOpiton.text], // update the value of specific key
      },
      FilteredDataLoaded: true,
    }));

    this.getFilteredSolutionItems(filterQuery);
  }
  getFilteredSolutionItems(filterQuery: {
    Area: string[];
    Technology: string[];
    SubServiceLine1: string[];
    GDSLocation: string[];
    CertificationType: string[];
    CertificationFor: string[];
  }) {
    // var newFilterQuery = filterQuery;
    //Deleting 'ALL' option
    let SolutionDetails = this.getAuditphaseFilterItems(
      this.state.AuditTagsValue,
      this.state.RequestTags,
      this.state.SearchText
    );
    Object.keys(filterQuery).forEach(
      (key) =>
        (filterQuery[key].length == 0 ||
          filterQuery[key][0] ==
            constants.SPFXConstants.Constants.DropDownOptionALL) &&
        delete filterQuery[key]
    );
    var result = SolutionDetails.filter(function (item) {
      return Object.keys(filterQuery).every(function (key) {
        return filterQuery[key].some(function (value) {
          if (key == "CertificationFor"){
            return item["CertifiedRegion"].filter((e: any) => e.Title === value).length > 0
          } else{
            if(item[key] !== null)
             return item[key].indexOf(value) != -1;
          }
          
          //return item[key] === value;
         
        });
      });
    });

    this.setState({
      FilteredSolutionDetails: result,
      FilteredDataLoaded: true,
    });
   this.scrollToCards();
  }

  // private onSelectedItem(data: { key: string; name: string }[]) {
    
  //  for (const item of data) {
  //     if (this.RequestTagsValue.indexOf(item.name) > -1) {
  //       let requesttags = this.RequestTagsValue;
  //       const index = requesttags.indexOf(item.name);
  //       requesttags.splice(index, 1);
  //       if (index > -1) {
  //         this.setState(
  //           {
  //             RequestTagsValue: requesttags,
  //           }
  //         );
  //       }
  //     } else {
  //       this.setState(
  //         (prevState) => ({
  //           RequestTagsValue: [...prevState.RequestTagsValue, item.name],
  //         })
  //       );
  //     }
  //     // console.log(`Item value: ${item.key}`);
  //     // console.log(`Item text: ${item.name}`);
  //   }
  // }

  RenderSolutions(): React.ReactNode {
    if (this.state.FilteredSolutionDetails.length > 0) {
      return <div className="solutions">
        {this.RenderSmallCardView()}
        {this.RenderPaging(this.state.FilteredSolutionDetails.length, constants.SPFXConstants.Constants.PaginationPageSize)}
      </div>;
      {
        /* {this.RenderPaging(this.state.FilteredSolutionDetails.length, constants.SPFXConstants.Constants.PaginationPageSize)} */
      }
    } else if (!this.state.FilteredDataLoaded) {
      return (
        <div
          style={{ position: "fixed", left: "100px" }}
          className="GDSSpinner"
        >
          <GDSSpinner />
        </div>
      );
    } else if (this.state.FilteredDataLoaded) {
      return (
        <div className={styles.noSolMsg}>
          {constants.SPFXConstants.Constants.Message_NoInformationAvailable}
        </div>
      );
    }
  }

  RenderDetailedViewForm(): React.ReactNode {
    return this.state.ViewDetailedSolution ? (
      <DetailedView
        ViewDetailedItem={this.state.ViewDetailedSolution}
        onBackLinkClick={this.onBackLinkClick.bind(this)}
        subServiceLines={this.state.SubServiceLine1}
        absoluteUrl={this.props.absoluteUrl}
        {...this.props}
      />
    ) : (
      <div style={{ position: "fixed", left: "100px" }} className="GDSSpinner">
        <GDSSpinner />
      </div>
    );
  }

  RenderPaging(ItemsCount: any, PaginationPageSize: any): React.ReactNode {
    //to get number of pages to construct
    var NoOfPages = Math.floor(ItemsCount / PaginationPageSize);  //2      
    //remining items for the last page
    var reminderItemsPage = (ItemsCount % PaginationPageSize);  //5
    //Final number of pages to construct
    NoOfPages = (reminderItemsPage > 0 ? (NoOfPages + 1) : NoOfPages);

    if (ItemsCount > PaginationPageSize) {
      return <div className="pagination">
        <a className={this.state.PaginationPreviousCSS} onClick={this.pagePreviousClick.bind(this, 1, NoOfPages)}>{constants.SPFXConstants.Constants.PaginationPrevious}</a>
        {this.renderPages(NoOfPages, reminderItemsPage)}
        <a className={this.state.PaginationNextCSS} onClick={this.pageNextClick.bind(this, 1, (NoOfPages))}>{constants.SPFXConstants.Constants.PaginationNext}</a>
      </div>
    }
  }

  renderPages(NoOfPages: number, reminderItemsPage: number): React.ReactNode {
    let anchorTags = [];
    for (let i = 0; i < NoOfPages; i++) {
      anchorTags.push(<a className={(this.state.PaginationCurrentPage == i + 1 ? this.state.PaginationCurrentCSS : '')} onClick={this.pageClick.bind(this, (i + 1), NoOfPages)}>{i + 1}</a>)
    }
    /*if (NoOfPages >= 0 && reminderItemsPage > 0)
       anchorTags.push(<a className={(this.state.PaginationCurrentPage == NoOfPages ? this.state.PaginationCurrentCSS : '')} onClick={this.pageClick.bind(this, NoOfPages, NoOfPages)}>{NoOfPages}</a>)*/
    return anchorTags;
  }

  pageClick(currentPageNo, lastPage): (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void {
    this.enableDisablePrevNextButtons(currentPageNo, 1, lastPage);
    return;
  }

  pagePreviousClick(firstPageNo, lastPageNo): (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void {
    var pageNo = this.state.PaginationCurrentPage - 1;

    this.enableDisablePrevNextButtons(pageNo, firstPageNo, lastPageNo);
    return;
  }

  pageNextClick(firstPageNo, lastPageNo): (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void {
    var pageNo = this.state.PaginationCurrentPage + 1;

    this.enableDisablePrevNextButtons(pageNo, firstPageNo, lastPageNo);
    return;
  }

  enableDisablePrevNextButtons(
    currentPageNo: any,
    firstPageNo: any,
    lastPageNo: any
  ) {
    if (currentPageNo == firstPageNo) {
      this.setState({
        PaginationCurrentPage: currentPageNo,
        PaginationPreviousCSS: "disabled",
        PaginationNextCSS: "",
      });
    } else if (currentPageNo == lastPageNo) {
      this.setState({
        PaginationCurrentPage: currentPageNo,
        PaginationPreviousCSS: "",
        PaginationNextCSS: "disabled",
      });
    } else if (currentPageNo >= firstPageNo && currentPageNo <= lastPageNo) {
      this.setState({
        PaginationCurrentPage: currentPageNo,
        PaginationNextCSS: "",
        PaginationPreviousCSS: "",
      });
    }
  }

  RenderSmallCardView(): React.ReactNode {
    let pageSize = constants.SPFXConstants.Constants.PaginationPageSize;
    //to hold the start index based on currentPage
    let sliceItemsStartIndex =
      (this.state.PaginationCurrentPage - 1) * pageSize;
    //to hold the end index based on currentPage
    let sliceItemsEndIndex = this.state.PaginationCurrentPage * pageSize;
    //gets the items in between start index and end index from object
    if (this.state.FilteredSolutionDetails.length > 0)
      var SliceFilteredSolutionDetails =
        this.state.FilteredSolutionDetails.slice(
          sliceItemsStartIndex,
          sliceItemsEndIndex
        );
    else
      var SliceFilteredSolutionDetails = this.state.SolutionDetails.slice(
        sliceItemsStartIndex,
        sliceItemsEndIndex
      );

    let row = [];
    var k = 0;
    // Outer loop to create parent
    for (let i = 0; i < constants.SPFXConstants.Constants.PaginationRows; i++) {
      let children = [];
      //Inner loop to create children
      for (
        let j = 0;
        j < constants.SPFXConstants.Constants.PaginationItemsInRow;
        j++
      ) {
        children.push(
          this.RenderCardViewInRows(SliceFilteredSolutionDetails[k])
        );
        k++;
      }
      //Create the parent and add the children
      row.push(<div className="linerow mb-1">{children}</div>);
    }
    return row;
  }

  private RenderCardViewInRows(solution: IGDSSolutionItem): JSX.Element {
    if (solution != undefined) {
      return (
        <div className="col-md-3">
          <div className="solution-box">
            <div
              className={styles.solutionBoxChild}
              onClick={() => {
                this.onDetailedViewClick(solution);
              }}
            >
              {this.getCardContentFront(solution)}
              {this.getCardContentBack(solution)}
            </div>
            {/* <p className="txt-grey">Approved for use in: <span>{GDSService.formatSolutionColumnValue(solution.GDSRegionalGeography)}</span></p>
            <p className="txt-grey mb-22">Restricted to: <span>{GDSService.formatSolutionColumnValue(solution.GDSRestrictedTo)}</span></p> */}
            {/* <p className={`likeBtn-${GDSService.getSolutionLikeColorClassName(this.state.TrackLikesData, solution.GDSSolutionID, this.props['GDSLoggedInUser'][0].Email)}`}><a className="thumbsup" onClick={this.onLikeClick.bind(this, solution.GDSSolutionID, solution.GDSName)}><i className="fa fa-thumbs-up fa-2x"></i></a> {GDSService.getSolutionLikeCount(this.state.TrackLikesData, solution.GDSSolutionID)}</p>
            <div className={this.getBadgeColor(solution)}>{this.getBadgeName(solution)}</div>  */}
          </div>
        </div>
      );
    } else <div></div>;
  }

  private getCardContentFront(solution: IGDSSolutionItem): React.ReactElement {
    return (
      <div className={styles.cardFrontView}>
        <div className={styles.cardsImageContainer}>
          <Image
            className={styles.cardsImage}
            src={solution.ProjectImage["Url"]}
            alt={solution.Title}
          />
        </div>
        <div className="sol-header" title={solution.Title}>
          <h4>{solution.Title}</h4>
        </div>
        <div className="sol-subheader">
          <h5>
            {solution.CertificationType} |
            <img
              src={
                constants.SPFXConstants.Constants.UserPhotoUrlSize +
                solution.SolutionOwner["EMail"]
              }
            />
            {solution.SolutionOwner["Title"]}
          </h5>
        </div>
       
        <div style={{ display: "inline-block", width: "100%" }}>
          <div className="txt-grey mb-08">
          {solution.CertifiedRegion.length > 0 ? "Approved Region:" : null} 
          {/* Approved Region: */}
          <b>{solution.CertifiedRegion.map((e: any) => {
                      return e.Title;
                    })}</b>
          </div>
          {/* <div className={styles.col-md-8 + " " + styles.}>Sub Service Line: <b>{solution.SubServiceLine1}</b></div> */}
        </div>
        <div style={{ display: "inline-block", width: "100%" }}>
          <div className="txt-grey mb-08">
            Sub Service Line: <b>{solution.SubServiceLine1}</b>
          </div>
          {/* <div className={styles.col-md-8 + " " + styles.}>Sub Service Line: <b>{solution.SubServiceLine1}</b></div> */}
        </div>
        <div style={{ display: "inline-block", width: "100%" }}>
          <div className="txt-grey mb-08">
            Category: <b>{solution.Category}</b>
          </div>
        </div>
        <div style={{ display: "inline-block", width: "100%" }}>
          <div className="txt-grey mb-08">
            Area: <b>{solution.Area}</b>
          </div>
        </div>
        {this.renderCardFooter(solution)}
      </div>
    );
  }

  private getCardContentBack(solution: IGDSSolutionItem): React.ReactElement {
    return (
      <div className={styles.cardBackView}>
        <p className="txt-white" title={solution.SolutionDescription}>
          {solution.SolutionDescription}
        </p>
        {this.renderCardFooter(solution)}
      </div>
    );
  }

  private renderCardFooter(solution: IGDSSolutionItem): React.ReactElement {
    return (
      <div>
        <DefaultButton
          style={{ width: "60px", minWidth: "50px" }}
          className="view-sol-form-btn btn-yellow"
          onClick={() => {
            this.onDetailedViewClick(solution);
          }}
          text="View"
        />
        <div style={{ float: "right" }}>
          <IconButton
            className="IconButton"
            label={`${solution.DownloadsCount}' Downloads'`}
            iconProps={constants.SPFXConstants.Constants.donloadButtonIcon}
            title="Downlaod Solution"
            ariaLabel="Emoji"
            disabled={true}
          />
          <span
            style={{
              padding: "5px 10px 0 0",
              marginLeft: "-5px",
              display: "inline-block",
              fontSize: "1.1em",
            }}
          >{`${solution.DownloadsCount || 0}`}</span>
          <IconButton
            className="IconButton"
            iconProps={constants.SPFXConstants.Constants.likeButtonIcon}
            title="like"
            ariaLabel="Emoji"
            disabled={true}
          />
          <span
            style={{
              padding: "5px 10px 0 0",
              marginLeft: "-5px",
              display: "inline-block",
              fontSize: "1.1em",
            }}
          >{`${solution.LikesCount || 0}`}</span>
          <IconButton
            className="IconButton"
            iconProps={constants.SPFXConstants.Constants.viewButtonIcon}
            title="Views"
            ariaLabel="Emoji"
            disabled={true}
          />
          <span
            style={{
              padding: "5px 10px 0 0",
              marginLeft: "-5px",
              display: "inline-block",
              fontSize: "1.1em",
            }}
          >{`${solution.ViewsCount || 0}`}</span>
        </div>
      </div>
    );
  }

  openDownloadDialog = (
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>
  ): void => {
    this.setState((prevState) => ({
      DownloadDialog: !prevState.DownloadDialog,
    }));
  };

  onBackLinkClick(detailedViewItem: IGDSSolutionItem) {
    this.state.SolutionDetails.filter(
      (sol) => sol.Id == detailedViewItem.Id
    )[0] = detailedViewItem;
    this.state.FilteredSolutionDetails.filter(
      (sol) => sol.Id == detailedViewItem.Id
    )[0] = detailedViewItem;
    this.setState({
      SolutionDetails: this.state.SolutionDetails,
      FilteredSolutionDetails: this.state.FilteredSolutionDetails,
    });
    this.props.routerContext.history.push(
      constants.SPFXConstants.Routing.HomePagePath
    );
    //getting all likes items

    //  var trackLikesData = this.state.TrackLikesData;

    //  //getting itemIndex, to update the likes item
    //  var filteredItemIndex = trackLikesData.map(updatedItem => { return updatedItem.id }).indexOf(UpdatedLikesData[0].id);

    //  //Item not found, then add item to likes data
    //  if(filteredItemIndex == -1)
    //  {
    //    trackLikesData.push(UpdatedLikesData[0]);
    //  }
    //  else {
    //  //updating the likes items with updated values
    //  trackLikesData[filteredItemIndex] = UpdatedLikesData[0];
    //  }

    // this.setState((prevState) => ({
    //    ShowDetailedViewForm: !prevState.ShowDetailedViewForm,

    // }));
    this.setState({
      ShowDetailedViewForm: false,
    });
  }
  //event: React.MouseEvent<HTMLDivElement, MouseEvent>
  onDetailedViewClick = (solution: IGDSSolutionItem): void => {
    // this.setState((prevState) => ({

    //    ShowDetailedViewForm: !prevState.ShowDetailedViewForm,
    //    ViewDetailedSolution: solution
    // }));
    this.setState({
      ShowDetailedViewForm: !this.state.ShowDetailedViewForm,
      ViewDetailedSolution: solution,
    });

    let route: string = "";
    route = constants.SPFXConstants.Routing.ToolDetails;
    this.props.routerContext.history.push(
      route.replace(":Id", solution.Id.toString())
    );
    // let submitData = {
    //    Views: solution.ViewsCount + 1
    // }
    // let webitem = new Web(this.props.context.pageContext.web.absoluteUrl).lists.getByTitle(constants.SPFXConstants.Constants.AutomationRack).items.getById(solution.Id);
    // webitem.update(submitData).then((response) => {
    // }).catch(error => { console.log(error) });
  };

  onLikeClick = (
    solutionId: string,
    solutionName: string,
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>
  ): void => {
    event.stopPropagation();
    var clickType = "Like";
    var loggedInUserEmail = this.props["GDSLoggedInUser"][0].Email;
    let web = new Web(this.props.context.pageContext.web.absoluteUrl);

    web.lists
      .getByTitle("Downloads And Likes")
      .items.select("*")
      .filter("Title eq'" + solutionId + "'")
      .top(5000)
      .get();
    GDSService.clickLikesDownloadCount(
      solutionId,
      solutionName,
      loggedInUserEmail,
      clickType,
      this.props.context.pageContext.web.absoluteUrl,
      this.props.context.pageContext.web.serverRelativeUrl,
      this.props.spHttpClient
    ).then((submitLikesTracker) => {
      if (submitLikesTracker == "UserAlreadyLiked") {
      } else if (submitLikesTracker != -1) {
        console.log("Success");
        var tempTrackLikes = this.state.TrackLikesData;
        var index = this.state.TrackLikesData.map((x) => {
          return x.GDSSolutionID;
        }).indexOf(solutionId);
        //New item to be created in tracker list if item not found
        if (index === -1) {
          tempTrackLikes.push(submitLikesTracker);
        } else {
          //tempTrackLikes[index].GDSTrackLikes = submitLikesTracker.GDSTrackLikes;
          tempTrackLikes[index] = submitLikesTracker;
        }

        this.setState({
          TrackLikesData: tempTrackLikes,
        });
      } else {
        console.log("Fail");
      }
    });
  };
  // renderTableHeader() {
  //    // if (this.state.SolutionDetails.length > 0) {
  //    let header = Object.keys(this.state.SolutionDetails[0])
  //    return header.map((key, index) => {
  //       return <th key={index}>{key.toUpperCase()}</th>
  //    })
  //    // }
  // }

  // renderTableData() {
  //    return this.state.SolutionDetails.map((solution, index) => {
  //       //const { id, name, age, email } = solution //destructuring
  //       return (
  //          <tr key={solution.SolutionName}>
  //             <td>{solution.SolutionName}</td>
  //             <td>{solution.SolutionType}</td>
  //             <td>{solution.SolutionVersion}</td>
  //             <td>{solution.SolutionDescription}</td>
  //             <td>{solution.SolutionSector}</td>
  //          </tr>
  //       )
  //    })
  // }
  loadCSS(): Promise<void> {
    SPComponentLoader.loadCss(
      constants.SPFXConstants.Constants.cdnPath +
        constants.SPFXConstants.Constants.cssMainPath
    );
    SPComponentLoader.loadCss(
      "https://fonts.googleapis.com/css?family=Noto+Sans:400,700&display=swap"
    );
    SPComponentLoader.loadCss(
      "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    );
    SPComponentLoader.loadCss(
      constants.SPFXConstants.Constants.SlickCssFileUrl
    );
    SPComponentLoader.loadCss(
      constants.SPFXConstants.Constants.SlickThemeFileUrl
    );
    return Promise.resolve();
  }
}
