import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { Dropdown, IDropdown, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import * as constants  from '../../constants';

export class GDSDropDown extends React.Component<any, any> {
    

    constructor(props) {
        super(props);        
     }

    public render() {
        return <Dropdown
        //componentRef={dropdownRef}
        placeholder="Select an option"
        defaultSelectedKey= {this.props.defaultSelectedKey}
        selectedKey={this.props.selectedKeys}
        label={this.props.label}
        options={this.props.options}        
        required={false}
        onChange={this.changeHandler.bind(this)}
        styles={{ dropdown: { width: '100%'}, 
                  title:{ borderRadius: '5px', background: 'transparent', 
                  border: '1px solid #c4c4cc !important' },
                //   border: '1px solid #c4c4cc !important', borderLeftColor: 'yellow !important' },
                  caretDown: { fontWeight: 'bolder', fontSize:'20px'},
                //   caretDown: { fontWeight: 'bolder', fontSize:'20px', color:'black'},
                //   label: {color:'#ffe600'},
               }}
         errorMessage={this.props.errorMessage}      
     />;
    }

    //changeHandler(): (event: React.FormEvent<HTMLDivElement>, option?: import("office-ui-fabric-react/lib/Dropdown").IDropdownOption, index?: number) => void {
      //  return this.props.onChange(event);
     //}

     changeHandler = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number): void =>
     {
        this.props.onChange(option);
     }
     
}