import * as React from 'react'
import * as ReactDOM from 'react-dom';
import {Spinner, SpinnerSize} from 'office-ui-fabric-react/lib/Spinner';
import * as constants  from '../../constants';

export class GDSSpinner extends React.Component<any, any> {

    constructor(props) {
        super(props);        
     }
  

    public render() {
        return <Spinner size={SpinnerSize.large} label={constants.SPFXConstants.Constants.spinnerLoadingText} ariaLive="assertive" />;
    }
}