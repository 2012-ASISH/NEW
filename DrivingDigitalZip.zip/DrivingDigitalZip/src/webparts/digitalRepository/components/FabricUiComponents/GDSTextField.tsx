import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { TextField, ITextFieldProps } from 'office-ui-fabric-react/lib/TextField';
import { GDSToolTip } from './GDSToolTip';

export class GDSTextField extends React.Component<any, any> {   

    constructor(props) {
        super(props);        
     }

    public render() {
        return <TextField 
        aria-labelledby={"label_1"}
        multiline={this.props.multiline}
        label={this.props.label}
        value={this.props.textValue}
        placeholder={this.props.placeholder}
        onChange={this._onChange}       
        styles={{ fieldGroup: { width: '100%', border:'0px'},
                  field: { borderRadius: '5px', background: 'transparent !important', 
                  border: '1px solid #c4c4cc !important', borderLeftColor: 'yellow !important' }
               }}
        errorMessage={this.props.errorMessage}
        onRenderLabel={this._onRenderSuffixLabel}
        />        
    }

    private _onRenderSuffixLabel = (props: ITextFieldProps): JSX.Element => {

        if (this.props.toolTip != undefined) {
            return ( <GDSToolTip {...this.props} />);
        }
        else
        {
            return <div><label id={"label_1"}>{this.props.label}</label></div>
        }
    }
    
    _onChange = (event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string): void => {
      this.props.onChange(newValue);
    }
}

{/* <div>
                    <label id={"label_1"}>{this.props.label}
                    <TooltipHost content={this.props.toolTip}
                        // Give the user more time to interact with the tooltip before it closes
                        closeDelay={500} id={"toolTip_1"}
                        calloutProps={calloutProps}
                        styles={styles}
                    ><IconButton
                            id={"icon_1"}
                            iconProps={{ iconName: 'Info' }}
                            title=""
                            ariaLabel="Info"
                            styles={{ root: { verticalAlign: 'top' } }}
                        /></TooltipHost></label>
                </div> */}