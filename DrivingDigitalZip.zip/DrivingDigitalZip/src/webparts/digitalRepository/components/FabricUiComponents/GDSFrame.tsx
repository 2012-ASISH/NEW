import * as React from 'react'
import * as ReactDOM from 'react-dom';
// import { Tabs } from '../Tabs/Tabs';
import * as constants from '../../constants';
import { GDSTextField } from './GDSTextField';
import { GDSDropDown } from './GDSDropDown';
import { GDSSpinner } from './GDSSpinner';
import { GDSRadioOptions } from './GDSRadioOptions';
import { GDSPeoplePicker } from './GDSPeoplePicker';
import { values } from '@uifabric/utilities';

export class GDSFrame extends React.Component<any, any> {

   constructor(props) {
      super(props);    
   }

   public componentDidMount() {
   }

   render() {
      return (
         <div style={{display: 'none'}}>
             <iframe src={this.props.iframeSrc} />
         </div>
       );
   }   
}

