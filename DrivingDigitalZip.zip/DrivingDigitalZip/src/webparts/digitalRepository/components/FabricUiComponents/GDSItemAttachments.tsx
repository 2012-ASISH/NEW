import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { ListItemAttachments } from '@pnp/spfx-controls-react/lib/ListItemAttachments';
import * as constants from '../../constants';

export class GDSItemAttachments extends React.Component<any, any> {

    constructor(props) {
        super(props);
    }


    public render() {
        return  <ListItemAttachments listId={this.props.listId}
        itemId={15}
        context={this.props.context}
        disabled={false} />                   
    }
}