import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { Checkbox } from 'office-ui-fabric-react/lib/Checkbox';
import * as constants  from '../../constants';

export class GDSCheckbox extends React.Component<any, any> {   

    constructor(props) {
        super(props);        
     }

    public render() {
        return <Checkbox label={this.props.label} checked={this.props.isChecked} onChange={this._onChange} />;
    }

  _onChange = (ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean): void => {
    this.props.onChange(checked);
  }  
}