import * as React from 'react'
import { TooltipHost, ITooltipHostStyles } from 'office-ui-fabric-react/lib/Tooltip';
import { IconButton } from 'office-ui-fabric-react/lib/Button';

const styles: Partial<ITooltipHostStyles> = { root: { display: 'inline-block' } };
const calloutProps = { gapSpace: 0 };

export class GDSToolTip extends React.Component<any, any> {

    constructor(props) {
        super(props);
    }

    public render() {
        return <div>
            <label id={"label_1"}>{this.props.label}
                <TooltipHost content={this.props.toolTip}
                    // Give the user more time to interact with the tooltip before it closes
                    closeDelay={500} id={"toolTip_1"}
                    calloutProps={calloutProps}
                    styles={styles}
                >
                    <IconButton
                        id={"icon_1"}
                        iconProps={{ iconName: 'Info' }}
                        title=""
                        ariaLabel="Info"
                        styles={{ root: { verticalAlign: 'top' } }}
                    />
                </TooltipHost></label>
        </div>
    }
}