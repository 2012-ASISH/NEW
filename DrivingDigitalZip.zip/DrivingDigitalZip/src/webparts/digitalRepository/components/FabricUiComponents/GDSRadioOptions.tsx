import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react/lib/ChoiceGroup';

export class GDSRadioOptions extends React.Component<any, any> {   

    constructor(props) {
        super(props);        
     }

    public render() {
        return <ChoiceGroup        
        defaultSelectedKey={this.props.defaultKey}
        selectedKey={this.props.selectedKey}
        options={this.props.options}
        onChange={this._onChange}
        label={this.props.label}
        required={false}
        styles={{
          flexContainer:{float:'left'}
        }}        
      />;
    }
    
    _onChange = (event: React.FormEvent<HTMLInputElement>, option: IChoiceGroupOption): void => {
      this.props.onChange(option);
    }
}