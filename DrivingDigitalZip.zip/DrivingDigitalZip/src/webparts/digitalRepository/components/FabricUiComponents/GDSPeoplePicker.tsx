import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import * as constants from '../../constants';
import { DirectionalHint } from 'office-ui-fabric-react/lib/Callout';
import { GDSToolTip } from './GDSToolTip';

export class GDSPeoplePicker extends React.Component<any, any> {

    constructor(props) {
        super(props);
    }


    public render() {
        return  <div>
                        {this.props.toolTip != "" ? <GDSToolTip {...this.props} /> : ""}
                        <PeoplePicker
                            context={this.props.context}
                            titleText={this.props.toolTip == "" ?  this.props.label : ""} //title will be passing to GDStooltip as props 
                            personSelectionLimit={this.props.personLimit}                            
                            defaultSelectedUsers={this.props.users}
                            groupName="" // Leave this blank in case you want to filter from all users
                            showtooltip={false}
                            tooltipMessage="tooltip info for people picker box"
                            tooltipDirectional={DirectionalHint.topCenter}
                            isRequired={false}
                            disabled={false}
                            selectedItems={this._getPeoplePickerItems.bind(this)}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            resolveDelay={1000}                            
                            //errorMessage={this.props.errorMessage}                            
                            peoplePickerWPclassName="GDSpplwp"
                            peoplePickerCntrlclassName="GDSpplcntrl"
                        />                        
                    </div>                   
    }

    _getPeoplePickerItems(items: any[]) {
        console.log('Items:', items);
        this.props.onSelectedItems(items);
    }
    //selectedItems={this._getPeoplePickerItems.bind(this, fieldInternalName)
}