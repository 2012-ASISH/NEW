import * as React from 'react'
import * as ReactDOM from 'react-dom';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import * as constants  from '../../constants';

export class GDSDialog extends React.Component<any, any> {   

    constructor(props) {
        super(props);
        this.state = {
          hideDialog: false
        }       
     }

    public render() {
        return <Dialog
        hidden={this.state.hideDialog}
        onDismiss={this._closeDialog}
        dialogContentProps={{
          type: DialogType.normal,
          //title: 'Missing Subject',
          closeButtonAriaLabel: 'Close',
          subText: this.props.message
        }}
        modalProps={{
          //titleAriaId: this._labelId,
          //subtitleAriaId: this._subTextId,
          isBlocking: true,
          styles: { main: { maxWidth: 450 } }          
        }}
      >
        <DialogFooter>          
          <DefaultButton onClick={this._closeDialog} text="Close" />
        </DialogFooter>
      </Dialog>
    }
  
    private _closeDialog = (): void => {
      this.setState({ hideDialog: true });
    };
}