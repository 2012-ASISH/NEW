import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { SPComponentLoader } from '@microsoft/sp-loader';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'DigitalRepositoryWebPartStrings';
import DigitalRepository from './components/DigitalRepository';
import { IDigitalRepositoryProps } from './components/IDigitalRepositoryProps';
import { sp } from "@pnp/sp";

export interface IDigitalRepositoryWebPartProps {
  description: string;
}

export default class DigitalRepositoryWebPart extends BaseClientSideWebPart <IDigitalRepositoryWebPartProps> {
/**
* Initialize the web part.
*/
protected onInit(): Promise<void> {
    SPComponentLoader.loadCss(`${this.context.pageContext.web.absoluteUrl}/Style%20Library/common.css`);
    SPComponentLoader.loadCss("https://fonts.googleapis.com/css?family=Noto+Sans:400,700&display=swap");
    SPComponentLoader.loadCss("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");

  sp.setup({
    spfxContext: this.context
  });

  return super.onInit();
}
  public render(): void {
    const element: React.ReactElement<IDigitalRepositoryProps> = React.createElement(
      DigitalRepository,
      {
        description: this.properties.description,
        context: this.context,
        spHttpClient: this.context.spHttpClient,
        absoluteUrl: this.context.pageContext.web.absoluteUrl,
      }

    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
