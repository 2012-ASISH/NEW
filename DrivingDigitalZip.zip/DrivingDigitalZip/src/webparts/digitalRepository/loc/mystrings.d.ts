declare interface IDigitalRepositoryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DigitalRepositoryWebPartStrings' {
  const strings: IDigitalRepositoryWebPartStrings;
  export = strings;
}
