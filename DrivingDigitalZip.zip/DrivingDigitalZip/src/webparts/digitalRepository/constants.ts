export namespace SPFXConstants {

    export class Constants {
      public static carousalImages: string="https://sites.ey.com/:f:/r/sites/DriveDigital/SiteAssets/Images/"
        public static cdnPath: string = "/sites/DriveDigital/";  // "/sites/cop/CDN/Governance";
        public static cssMainPath: string = "Style%20Library/SPFXCSS.css";
        public static ChangeStageFlowURL = "https://prod-73.westeurope.logic.azure.com:443/workflows/648f178c1c124985bd30afa2d2c22a48/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=fjQiZ6dPuCzapnNL5_5WhVD7ppiKYdVK3ghascVTkzw"
        

        public static donloadButtonIcon = { iconName: 'Download' };
        public static likeButtonIcon = { iconName: 'like' };
        public static viewButtonIcon = { iconName: 'RedEye' };
        public static SlickCssFileUrl= "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css";
        public static SlickThemeFileUrl= "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css";


        //Filter options
        public static technologyFilter = "Technology"
        public static subServiceLineFilter = "SubServiceLine1"
        public static areaFilter = "Area"
        public static GDSLocationFilter = "GDSLocation"
        public static Category = "Category"
        public static CertificationType = "CertificationType"
        public static Certifiedfor = "Certifiedfor"
        
        

        // //List URLs ATIC
        public static AutomationRack: string = "Automation Rack";
        public static GDSTrackLikesListUrl: string = "TrackLikesDownloads";
        
        //Request Roles
        public static AdminGroupName: string = "ATIC Admin"
        public static Admin: string = "Admin";
        public static ExecutiveSponcor: string = "ExecutiveSponcor";
        public static ToolOwner: string = "ToolOwner";
       
        //Stage
        public static Tool_Submission_Draft: string = "New Tool Draft"
        public static Tool_Submission_Pending_Owner_Review: string = "Pending Review "
        public static Tool_Submission_Pending_Sponsor_Certification: string = "Pending Attestation"
        public static Tool_Submission_Pending_Admin_Approval: string = "Pending Approval"
        public static Tool_Submission_Approved: string = "Approved"
        public static Tool_Deactivation_Pending_Owner_Confirmation: string = "Tool Deactivation - Pending owner Confirmation"
        public static Tool_Deactivation_Pending_Sponsor_Confirmation: string = "Tool Deactivation - Pending Sponsor Confirmation"
        public static Tool_Deactivation_Pending_Admin_Confirmation: string = "Tool Deactivation - Pending Admin Confirmation"
        public static Tool_Deactivation_Admin_Approved: string = "Tool Deactivation - Admin Approved"
   
        //Submit Form Field Labels Constants
        public static PrefixedText: string = "Attached file names will be automatically prefixed with";
        public static MaxSize: string = "(Max : 50MB)";
        public static UploadFileText: string = "Upload a file";
/////--------------------------------------------------------

public static spinnerLoadingText: string = "Loading...";

public static imagesPath: string = "/sites/GDS/SiteAssets/GDS/Images/";

//List Urls
public static GDSDigitalRackListUrl: string = "/Lists/GDSSolutions";
public static GDSMarketplaceListUrl: string = "/Lists/GDSMarketplace";
public static GDSSupportListUrl: string = "/Lists/GDSSupport";
public static GDSReportBugListUrl: string = "/Lists/GDSReportBug";
public static GDSSuggestionsListUrl: string = "/Lists/GDSSuggestions";
public static GDSSolutionOwnerAnnualConfirmationListUrl: string = "/Lists/GDSSolutionOwnerAnnualConfirmation";
public static GDSAreaOwnerAnnualConfirmationListUrl: string = "/Lists/GDSAreaOwnerAnnualConfirmation";
public static GDSConfigurationsListUrl: string = "/Lists/GDSConfigurations";
public static GDSAreaListUrl: string = "/Lists/GDSArea";
public static GDSRegionListUrl: string = "/Lists/GDSRegion";
public static GDSSectorListUrl: string = "/Lists/GDSSector";
public static GDSSolutionTypeListUrl: string = "/Lists/GDSSolutionType";
public static GDSPrimaryObjectiveListUrl: string = "/Lists/GDSPrimaryObjective";
public static GDSPromptedChangesListUrl: string = "/Lists/GDSPromptedChanges";
public static GDSSolutionsListUrl: string = "/Lists/GDSPromptedChanges";

//Page Titles Constants
public static PageTitle_DigitalRack: string = "Micro-solution marketplace";
public static PageTitle_MySubmissions: string = "My Submissions";
public static PageTitle_SubmitForm: string = "Micro-solution submission form";

//General Control Labels Constants
public static MySubmision_AnnualConfirmation_CheckBox: string = "Show solutions with annual confirmation pending";

//DropDown Constants
public static DropDownOptionALL: string = "ALL";

//RadioOptions Constants
public static RadioOptionSolutionOwner: string = "Solution Owner";
public static RadioOptionSolutionOwnerKey: string = "SolutionOwner";
public static RadioOptionSolutionContributor: string = "Solution Contributor";
public static RadioOptionSolutionContributorKey: string = "SolutionContributor";

//Pagination Constants
public static PaginationPrevious: string = "Previous";
public static PaginationNext: string = "Next";
public static PaginationItemsInRow: number = 4;
public static PaginationRows: number = 20;
public static PaginationPageSize: number = Constants.PaginationItemsInRow * Constants.PaginationRows;

 //Submit Form Field Labels Constants
 public static Ack1_Column: string = "I have searched the marketplace to verify that there are not any certified solutions that are functionally the same as the solution I am submitting";
 public static Ack2_Column: string = "I have read and understand the certification process and requirements";         
 public static Ack3_Column: string = "I have attached all required certification documents, and I acknowledge other documentation may be requested during the certification process?";
 public static Ack4_Column: string = "I acknowledge that as the Solution Owner I will be the primary contact to provide ongoing support for  the solution as long as it remains certified. I will be required to confirm annually to act in this role and provide related attestations regarding the functionality and relevancy of the solution.";
 public static Ack5_Column: string = "I have searched EY Atlas for globally or area approved solutions";         
 public static NewMicroSolutionOption: string = "New micro-solution";
 public static UpdateMicroSolutionOption: string = "Update an existing micro-solution";
 public static SolutionName: string = "Micro-solution name";
 public static SolutionDescription: string = "Briefly describe the micro-solution";
 public static TeamBenefits: string = "Briefly describe the expected benefits to a team using the solution";
 public static SolutionEnhancement: string = "Does the solution enhance or supplement functionality in an existing globally certified Helix or Canvas solution?";
 public static SolutionEnhanceYesOption: string = "Yes";
 public static SolutionEnhanceNoOption: string = "No";
 public static SolutionEnhanceDescribe: string = "Please Describe";
 public static EstimatedHours: string = "Estimated hours from an audit team";
 public static SolutionPrimaryObjective: string = "Primary objective of micro-solution";
 public static DescribePrimaryObjectiveOthers: string = "Describe the primary objective";
 public static SolutionOwner: string = "Solution owner";
 public static SolutionContributors: string = "Solution contributors";
 public static SolutionPPEDDSponsor: string = "PPEDD sponsor";
 public static SolutionArea: string = "Area in which solution to be certified";
 public static SolutionRegion: string = "Geography where the solution has been tested?";
 public static SolutionRegion_RestrictionsForUse: string = "Geography restrictions for use?";
 public static SolutionSector: string = "Applicable sector";
 public static SolutionRelatedAccountAuditArea: string = "Related account/audit area";
 public static SolutionType: string = "Software used, select all that apply";
 public static SolutionTypeOther: string = "Please specify the other software used";
 public static VersionNumber: string = "Version";         
 public static Attachment1: string = "Micro-solution with sanitized sample data";
 public static Attachment2: string = "Testing summary";
 public static Attachment3: string = "Data requirements";
 public static SolutionStatus: string = "Status";


 public static SolutionVersion: string;
 public static SolutionOwnerId: number;
 public static SolutionContributorsId: number[];         
 public static SolutionId: string;
 public static SolutionSummaryChanges: string = "Summary of changes made and how they were tested";
 public static SolutionPromptedChange: string = "What prompted the change?";
 public static MicroSolutionToUpdate: string = "Micro-solution to update";
 
 //Common List Column Internal Names
 public static InternalName_ID_Column: string = "Id";
 public static InternalName_Title_Column: string = "Title";
 public static InternalName_SolutionId: string = "GDSSolutionID";

  //Submit Form Field Internal Names Constants
  public static InternalName_Ack1_Column: string = "GDSAck1";
  public static InternalName_Ack2_Column: string = "GDSAck2";
  public static InternalName_Ack3_Column: string = "GDSAck3";
  public static InternalName_Ack4_Column: string = "GDSAck4";
  public static InternalName_Ack5_Column: string = "GDSAck5";
//   public static InternalName_NewMicroSolutionOption: string = "New-MicroSolution";
//   public static InternalName_UpdateMicroSolutionOption: string = "Update existing Micro-Solution";
  public static InternalName_SolutionName: string = "GDSName";
  public static InternalName_SolutionDescription: string = "GDSSolutionDescription";
  public static InternalName_TeamBenefits: string = "GDSBenefitsOfTeamDescription";      
  public static InternalName_SolutionEnhancementYesNo: string = "GDSSolutionEnhanceYesNo";    
  public static InternalName_SolutionEnhanceDescribe: string = "GDSSolutionEnhancements";          
  public static InternalName_EstimatedHours: string = "GDSEstimatedHours";
  public static InternalName_SolutionPrimaryObjective: string = "GDSPrimaryObjective";
  public static InternalName_SolutionPrimaryObjectiveOther: string = "GDSPrimaryObjectiveOther";
  public static InternalName_SolutionOwner: string = "GDSSolutionOwner";
  public static InternalName_SolutionContributors: string = "GDSSolutionContributors";
  public static InternalName_SolutionPPEDDSponsor: string = "GDSPPEDDSponsor";
  public static InternalName_SolutionArea: string = "GDSAreaCertified";
  public static InternalName_SolutionRegion: string = "GDSRegionalGeography";
  public static InternalName_SolutionRegion_Restrictions: string = "GDSRestrictedTo";
  public static InternalName_SolutionSector: string = "GDSApplicableSector";
  public static InternalName_SolutionSectorMulti: string = "GDSApplicableSectorMulti";
  public static InternalName_SolutionRelatedAccountAuditArea: string = "GDSRelatedAccount";
  public static InternalName_SolutionTypeOther: string = "GDSSolutionType";
  
  public static InternalName_SolutionTypeMulti: string = "GDSSolutionTypeMulti";
  public static InternalName_SolutionTypeTitles: string = "GDSSolutionTypeMultiTitles";
  public static InternalName_SolutionTypeNewOrUpdate: string = "GDSNewOrUpdateSolution";

  public static InternalName_SolutionVersion: string = "GDSVersion";
  public static InternalName_SolutionOwnerId: String = "GDSSolutionOwnerId";
  public static InternalName_SolutionContributorsId: string = "GDSSolutionContributorsId";
  public static InternalName_SolutionStatus: string = "GDSStatus";          
  public static InternalName_SolutionSummaryChanges: string = "GDSSummaryOfChanges";
  public static InternalName_SolutionPromptedChange: string = "GDSPromptedTheChange";
  public static InternalName_MicroSolutionToUpdate: string = "Micro-solution to update";


  //Report Bug Field Internal Names Constants
  public static InternalName_ReportBugAskedCommunityForAssistance: string = "GDSReportBugYes";
  public static InternalName_ReportBugSolutionOwnerNotResponsible: string = "GDSReportBugSolutionOwner";
  public static InternalName_ReportBugDescription: string = "GDSReportBugDescription";
  
  //Suggestions Field Internal Names Constants
  public static InternalName_SuggestionDescription: string = "GDSSuggestionDescription";      

  //Form Names
  public static ArchiveFormName: string = "ArchiveForm";
  public static MarketPlaceFormName: string = "MarketPlace";

  //Form Status
  public static FormStatus_Draft: string = "Draft";
  public static FormStatus_Submitted: string = "Submitted";
  public static FormStatus_PendingApproval: string = "Pending Approval";
  public static FormStatus_Rejected: string = "Rejected";
  public static FormStatus_Approved: string = "Approved";
  public static FormStatus_Unpublished: string = "Unpublished";
  public static FormStatus_ReadyToPublish: string = "Ready to publish";
  public static FormStatus_Published: string = "Published";
  public static FormStatus_Revoked: string = "Revoked";

  //Submit and Edit Form Tab Titles
  public static Form_Tab_Title_BasicInfo: string = "Basic information";
  public static Form_Tab_Title_OwnerShip: string = "Ownership and classification";
  public static Form_Tab_Title_Upload: string = "Upload and acknowledgement";


  //View form field labels
  public static View_Form_DescribeBenefits: string = "Describe benefits of a team using the solution";
  public static View_Form_RegionalGeography: string = "Regional geography where solution been tested?";
  public static View_Form_SolutionContributor: string = "Solution contributor";
  public static View_Form_SolutionType: string = "Solution type";

  //User Photo
  //production - "/_layouts/15/userphoto.aspx?size=S&accountname=";
  //workbench -  "./userphoto.aspx?size=S&accountname=";
  public static UserPhotoUrlSize: string = "/_layouts/15/userphoto.aspx?size=S&accountname=";

  //Message constants
  public static Message_NoInformationAvailable: string = "No Infomation Available";
  public static Message_NoSolutionsAvailable: string = "No Solutions Available";

  //Configuration Constants
  public static Config_SolutionOwner_AnnualConfirm_StartDate: string = "Solution Owner Annual Confirmation Start Date";
  public static Config_SolutionOwner_AnnualConfirm_EndDate: string = "Solution Owner Annual Confirmation End Date";
  public static Config_AreaOwner_AnnualConfirm_StartDate: string = "Area Owner Annual Confirmation Start Date";
  public static Config_AreaOwner_AnnualConfirm_EndDate: string = "Area Owner Annual Confirmation End Date";
  public static Config_Tooltip_Summarychanges: string = "Summarychanges_Tooltip";
  public static Config_Tooltip_Teambenefits: string = "Teambenefits_Tooltip";
  public static Config_Tooltip_Relatedaccount_Auditarea: string = "Relatedaccount_Auditarea_Tooltip";
  public static Config_Tooltip_OtherSoftware_Used: string = "Othersoftwareused_Tooltip";
  public static Config_Tooltip_SolutionOwner: string = "SolutionOwner_Tooltip";
  public static Config_Tooltip_SolutionContributors: string = "SolutionContributors_Tooltip";
  public static Config_Tooltip_PPEDDSponsor: string = "PPEDDSponsor_Tooltip";
  public static Config_Tooltip_Acknowledgement: string = "ACK_Tooltip"

  //Area TimeStamp names
  public static Area_Americas: string = 'americas';
  public static Area_Asiapac: string = 'asiapac';
  public static Area_Emeia: string = 'emeia';

   }

   const homPagePath = "/SitePages/DigitalRack.aspx";
   export const Routing = {
     HomePagePath: homPagePath,
     ToolDetails: homPagePath + "/:Id",
   }
   export const API = {
    ListItems: "{0}/_api/web/lists/GetByTitle('{1}')/items",
    SelectQuery: "?$select={0}",
    TopQuery:"&$top={0}",
    FilterQuery: "&$filter={0}",
  
  };

  export const ListNames = {
    RegionMapping:"RegionMapping",
    
};
}