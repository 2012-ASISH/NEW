import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions } from "@microsoft/sp-http";
import { ISolutionDetails } from "../Model/ISolutionDetails";
export class SPData {

    public static getListData(requestUrl: string, spHttpClient: SPHttpClient): any {
        //let requestUrl = siteUrl.concat("/_api/Web/GetList('" + webServerRelativeUrl + listUrl + "')/items");
        let listItems = [];
        return new Promise<string[][]>((resolve: (options: string[][]) => void, reject: (error: any) => void) => {
            return spHttpClient.get(requestUrl, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    response.json().then((responseJSON) => {
                        if (responseJSON.value != "") {
                            listItems = responseJSON.value;
                        }
                        resolve(listItems);
                    });
                }
            });
        });
    }
  

    public static AddItem(itemObj: {}, restUrl: string, headers: {}, spHttpClient: SPHttpClient): any {
        const options: ISPHttpClientOptions = {
            headers: headers,
            body: JSON.stringify(itemObj)
        };
        
        return new Promise<any>((resolve: (options: any) => void, reject: (error: any) => void) => {
            return spHttpClient.post(restUrl, SPHttpClient.configurations.v1, options)
                .then((resps) => {
                    resolve(resps);
                });
        });
    }

    static DeleteItem(restUrl: string, headers: {}, spHttpClient: SPHttpClient) {
        const options: ISPHttpClientOptions = {
            headers: headers           
        };
        
        return new Promise<any>((resolve: (options: any) => void, reject: (error: any) => void) => {
            return spHttpClient.post(restUrl, SPHttpClient.configurations.v1, options)
                .then((resps) => {
                    resolve(resps);
                });
        });
    }

    public static getCurrentUserGroupNames(webAbsoluteUrl: string, spHttpClient: SPHttpClient) {
        return new Promise<string[]>
          ((resolve: (options: string[]) => void, reject: (error: any) => void) => {           
            var groupRestApi = '';
            groupRestApi = webAbsoluteUrl + "/_api/web/currentuser/?$expand=groups";            
            return SPData.getGroups(groupRestApi, spHttpClient)
              .then((groupNamesArray) => {
                resolve(groupNamesArray);
              });
          });
      }

    public static getGroups(groupRestApi: string, spHttpClient: SPHttpClient): any {
        return new Promise<string[]>
          ((resolve: (options: string[]) => void, reject: (error: any) => void) => {
            let groupNames: string[] = [];
            spHttpClient.get(groupRestApi, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
              if (response.ok) {
                response.json().then((responseJSON) => {
                  if (responseJSON.Groups.length > 0) {
                    groupNames = responseJSON.Groups;
                  }
                  resolve(groupNames);
                });
              }
            });
          });
      }

      public static getUserIdByAccountName = (userAccountNamesArray: string[], webAbsoluteUrl: string, spHttpClient: SPHttpClient) => {

        return new Promise<string[]>((resolve: (options: any) => void, reject: (error: any) => void) => {

            return Promise.all(userAccountNamesArray.map((userAccountName, index) => {
                var url = '';
                url = webAbsoluteUrl + "/_api/web/siteusers(@v)?@v='" + encodeURIComponent(userAccountName["id"]) + "'";
                return SPData.getUserId(url, spHttpClient)
                    .then((listData: any) => {
                        return listData;
                    });
            })).then(function (data) {
                //console.log("all promises...done");                
                //console.log("all promises...after");
                resolve(data);
            });
        });
    }
    
    public static getUserId(requestUrl: string, spHttpClient: SPHttpClient) {
        return new Promise<string[]>((resolve: (options: any) => void, reject: (error: any) => void) => {
            return spHttpClient.get(requestUrl, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    var userId;
                    response.json().then((responseJSON) => {
                        if (responseJSON.Id != "") {
                            userId = responseJSON.Id;
                        }
                        resolve(userId);
                    });
                }
            });
        });
    }
}
