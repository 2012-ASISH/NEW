import * as React from 'react'
import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions } from "@microsoft/sp-http";
import { ISolutionDetails, IGDSAreaList, IGDSRegionList, IGDSSectorList, IGDSSolutionTypeList, IGDSDropDownStruct, IGDSPrimaryObjectiveList, IGDSPromptedChangeList, ISubmitSolutionDetails, IGDSSolutionItem, IGDSSupportItem, IGDSTrackLikesItem, IGDSSolutionOwnerAnnualConfirmationItem, IGDSConfigurationItem, IGDSMultiDropDownStruct, IGDSUserDetails } from "../Model/ISolutionDetails";
import * as constants from '../constants';
import { GDSDialog } from '../components/FabricUiComponents/GDSDialog';
import { SPData } from './SPData';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import "@pnp/sp/folders/web";
import "@pnp/sp/files/folder";
import "@pnp/sp/items/list";
import "@pnp/sp/fields/list";
import "@pnp/sp/views/list";
import "@pnp/sp/site-users/web";
import { IList } from "@pnp/sp/lists";
import * as _ from "lodash";
import { String } from "typescript-string-operations";
import * as Constants from '../constants';
import { IDropdownOption } from 'office-ui-fabric-react';
export class GDSService {     

    private lst_pageComments: string = '';
    private lst_pageDocuments: string = '';
    private lst_docListName: string = '';
    private _list: IList = null;
    private _doclist: IList = null;
   

    public static getCurrentUserInfo = async () => {
        let currentUserInfo = await sp.web.currentUser.get();
        return currentUserInfo.Email;
    }

    public static getSliderImages(UrlId): Promise<string[]>{
        return new Promise<string[]>((resolve: (options: string[]) => void, reject: (error: any) => void) => {
            sp.web.getFolderByServerRelativeUrl("SiteAssets/Images/"+UrlId).files.select("ServerRelativeUrl").get().then(resp=>{
                let images = [];
                resp.map(img => {
                    images.push(img.ServerRelativeUrl);
                });
                resolve(images);
            }).catch(ex=>{
                console.log(ex);
                resolve([]);
            });
        });
    }
    
    // public getDropdownOptions(
    //     requestUrl: string,
    //     spHttpClient: SPHttpClient
    //   ): Promise<Array<IDropdownOption>> {
    //     let dropdownOptions: Array<IDropdownOption> = [{key:"ALL",text:"ALL"}];
    //     return new Promise<Array<IDropdownOption>>(
    //       (resolve: (options: any) => void, reject: (error: any) => void) => {
    //         SPData
    //           .getListData(requestUrl,spHttpClient)
    //           .then((resp) => {
    //             resp.map((item) => {
    //               dropdownOptions.push({
    //                 key: item.Title,
    //                 text: item.Title,
    //               });
    //             });
    //             resolve(dropdownOptions);
    //           })
    //           .catch((ex) => {
    //             console.log("PMTService > getDropdownOptions > ", requestUrl, ex);
    //             resolve(dropdownOptions);
    //           });
    //       }
    //     );
    //   }
    public getSiteUsers = async (currentUserId: number) => {
        let resusers = await sp.web.siteUsers.filter('IsHiddenInUI eq false and PrincipalType eq 1').get();
        _.remove(resusers, (o) => { return o.Id == currentUserId || o.Email == ""; });
        let userResults = [];
        resusers.map((user) => {
            userResults.push({
                id: user.Id,
                fullname: user.Title,
                email: user.Email,
                profile_picture_url: '/_layouts/15/userphoto.aspx?size=S&username=' + user.UserPrincipalName
            });
        });
        return userResults;
    }

    public addLikeForSolution = async (solutionId, commentJson, currentUserInfo) => {
        var tempLikes = [];
        tempLikes.push({
            emailid: currentUserInfo.emailid 
        });
        let solution = await this._list.items.select('ID').getById(solutionId).get();
        if (solution.length > 0) {
            return await this._list.items.getById(solution[0].ID).update({ Likes: JSON.stringify(tempLikes) });
        }
    }
    public updateLikesForComment = async (solutionId, jsonLikes) => {
        let solution = await this._list.items.select('ID').getById(solutionId).get();
        if (solution.length > 0) {
            return await this._list.items.getById(solution[0].ID).update({ Likes: JSON.stringify(jsonLikes) });
        }
    }
    public LikeSolution = async (solutionId, SolutionJson, currentUserInfo) => {
        let res = await this._list.items.select('Likes', 'FieldValuesAsText/Likes').getById(solutionId).expand('FieldValuesAsText').get();
        if (res.length > 0) {
            var tempLikes = res[0].FieldValuesAsText.Likes;
            if (tempLikes != undefined && tempLikes != null && tempLikes !== "") {
                // Likes already exits so update the item
                var jsonLikes = JSON.parse(tempLikes);
                var userAlreadyVoted = _.find(jsonLikes, (o) => { return o.solutionId == SolutionJson.id && _.find(o.userVote, (oo) => { return oo.userid == currentUserInfo.ID; }); });
                var userPresent = (userAlreadyVoted === undefined || userAlreadyVoted == null) ? false : true;
                var fil = _.find(jsonLikes, (o) => { return o.commentID == SolutionJson.id; });
                if (fil !== undefined && fil !== null) {
                    // Found likes for the comment id
                    if (SolutionJson.user_has_upvoted) {
                        if (!userPresent) fil.userVote = _.concat(fil.userVote, { userid: currentUserInfo.ID, name: currentUserInfo.DisplayName });
                    } else {
                        if (userPresent) {
                            if (fil !== undefined && fil !== null) _.remove(fil.userVote, (o) => { return o['userid'] == currentUserInfo.ID; });
                        }
                    }
                } else {
                    // No likes found for the comment id
                    jsonLikes.push({ solutionID: SolutionJson.id, userVote: [{ userid: currentUserInfo.ID, name: currentUserInfo.DisplayName }] });
                }
                return await this.updateLikesForComment(solutionId, jsonLikes);
            } else {
                // Likes doesn't exists so add new
                if (SolutionJson.user_has_upvoted) return await this.addLikeForSolution(solutionId, SolutionJson, currentUserInfo);
            }
        } else {
            return SolutionJson;
        }
    }




   
    static getLoggedInUserDetails(absoluteUrl: string, spHttpClient: SPHttpClient) {
        var currentUserRestApi = absoluteUrl + "/_api/web/currentuser?$select=Title,Email,Id,LoginName";

        return new Promise<string[]>((resolve: (options: string[]) => void, reject: (error: any) => void) => {
            let userDetails: string[] = [];
            spHttpClient.get(currentUserRestApi, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    response.json().then((responseJSON) => {
                        if (responseJSON != "") {
                            userDetails.push(responseJSON);
                        }
                        resolve(userDetails);
                    });
                }
            });
        });
    }

    static getUserDetailsFromSPGroup(requestUrl: string, spHttpClient: SPHttpClient) {
        //var currentUserRestApi = absoluteUrl + "/_api/web/currentuser?$select=Title,Email,Id,LoginName";
        let userDetails: IGDSUserDetails[] = [];
        return new Promise<IGDSUserDetails[]>((resolve: (options: IGDSUserDetails[]) => void, reject: (error: any) => void) => {           
            spHttpClient.get(requestUrl, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    response.json().then((responseJSON) => {
                        responseJSON.value.map(userDetail => {
                            userDetails.push({
                                Title: userDetail.Title,
                                Email: userDetail.Email,
                                LoginName: userDetail.LoginName
                            });
                        });
                        resolve(userDetails);
                    });
                }
            });
        });
    }

    static getLoggedInUserArea(absoluteUrl: string, spHttpClient: SPHttpClient, LoginName: string) {
        var currentUserRestApi =  absoluteUrl + "/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='"+ LoginName.replace("#", "%23") +"'";

        return new Promise<string[]>((resolve: (options: string[]) => void, reject: (error: any) => void) => {
            let userDetails: string[] = [];
            spHttpClient.get(currentUserRestApi, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
                if (response.ok) {
                    response.json().then((responseJSON) => {
                        // if (responseJSON != "") {
                        //     userDetails.push(responseJSON);
                        // }
                        resolve(responseJSON);
                    });
                }
            });
        });
    }

    static getGDSAreaListData(absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient) {
        
        let requestUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + listUrl + "')/items");
        let listData: IGDSAreaList[] = [];
        return new Promise<IGDSAreaList[]>((resolve: (options: IGDSAreaList[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Title: listItem.Title
                        });
                    });
                    resolve(listData);
                });
        });
    }

    static GDSRegionList(absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient) {
        let requestUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + listUrl + "')/items?$select=Title,GDSArea/Title&$expand=GDSArea/Title");
        let listData: IGDSRegionList[] = [];
        return new Promise<IGDSRegionList[]>((resolve: (options: IGDSRegionList[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Title: listItem.Title,
                            Area: listItem.GDSArea.Title
                        });
                    });
                    resolve(listData);
                });
        });
    }

    static GDSSectorList(absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient) {
        let requestUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + listUrl + "')/items");
        let listData: IGDSSectorList[] = [];
        return new Promise<IGDSSectorList[]>((resolve: (options: IGDSSectorList[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Id: listItem.Id,
                            Title: listItem.Title
                        });
                    });
                    resolve(listData);
                });
        });
    }

    static GDSSolutionTypeList(absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient) {
        let requestUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + listUrl + "')/items");
        let listData: IGDSSolutionTypeList[] = [];
        return new Promise<IGDSSolutionTypeList[]>((resolve: (options: IGDSSolutionTypeList[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Id: listItem.Id,
                            Title: listItem.Title
                        });
                    });
                    resolve(listData);
                });
        });
    }

    static GDSPrimaryObjectiveList(absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient) {
        let requestUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + listUrl + "')/items");
        let listData: IGDSPrimaryObjectiveList[] = [];
        return new Promise<IGDSPrimaryObjectiveList[]>((resolve: (options: IGDSPrimaryObjectiveList[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Title: listItem.Title
                        });
                    });
                    resolve(listData);
                });
        });
    }

    static GDSPromptedChangeList(absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient) {
        let requestUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + listUrl + "')/items");
        let listData: IGDSPromptedChangeList[] = [];
        return new Promise<IGDSPromptedChangeList[]>((resolve: (options: IGDSPromptedChangeList[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Title: listItem.Title
                        });
                    });
                    resolve(listData);
                });
        });
    }

    public static getSolutionsListItemData(requestUrl: string, spHttpClient: SPHttpClient, FormName: string): any {
        let listData: IGDSSolutionItem[] = [];
        return new Promise<IGDSSolutionItem[]>((resolve: (options: IGDSSolutionItem[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        // listData.push({
                        //     Id: listItem.Id,
                        //     Title: (listItem.Title != undefined && listItem.Title != null ? listItem.Title : ''),
                            // GDSName: (listItem.GDSName != undefined && listItem.GDSName != null ? listItem.GDSName : ''),
                            // GDSSolutionType: (listItem.GDSSolutionType != undefined && listItem.GDSSolutionType != null ? listItem.GDSSolutionType : ''),
                            // GDSSolutionTypeMultiTitles: this.getUserTitles(listItem.GDSSolutionTypeMulti),   //(listItem.GDSSolutionTypeMulti != undefined && listItem.GDSSolutionTypeMulti != null ? listItem.GDSSolutionTypeMulti : ''),
                            // GDSSolutionTypeMulti: this.getLookUpIds(listItem.GDSSolutionTypeMulti),
                            // GDSVersion: (listItem.GDSVersion != undefined && listItem.GDSVersion != null ? listItem.GDSVersion : ''),
                            // GDSSolutionDescription: (listItem.GDSSolutionDescription != undefined && listItem.GDSSolutionDescription != null ? listItem.GDSSolutionDescription : ''),
                            // //GDSApplicableSector: (listItem.GDSApplicableSector != undefined && listItem.GDSApplicableSector != null ? listItem.GDSApplicableSector : ''),
                            // GDSApplicableSectorMultiTitles: this.getUserTitles(listItem.GDSApplicableSectorMulti),   //(listItem.GDSSolutionTypeMulti != undefined && listItem.GDSSolutionTypeMulti != null ? listItem.GDSSolutionTypeMulti : ''),
                            // GDSApplicableSectorMulti: this.getLookUpIds(listItem.GDSApplicableSectorMulti),
                            // GDSAreaCertified: (listItem.GDSAreaCertified != undefined && listItem.GDSAreaCertified != null ? listItem.GDSAreaCertified : ''),
                            // //GDSRegionalGeography: (listItem.GDSRegionalGeography != undefined && listItem.GDSRegionalGeography != null ? listItem.GDSRegionalGeography : ''),
                            // //GDSRegionalGeographyTitles: listItem.GDSRegionalGeography,   //(listItem.GDSSolutionTypeMulti != undefined && listItem.GDSSolutionTypeMulti != null ? listItem.GDSSolutionTypeMulti : ''),
                            // GDSRegionalGeography: this.getRegionalGeog(listItem.GDSRegionalGeography),
                            // GDSRestrictedTo: (listItem.GDSRestrictedTo != undefined && listItem.GDSRestrictedTo != null ? this.getRegionalGeog(listItem.GDSRestrictedTo) : []),
                            // GDSSolutionOwnerId: (listItem.GDSSolutionOwnerId != undefined && listItem.GDSSolutionOwnerId != null ? listItem.GDSSolutionOwnerId : ''),
                            // GDSSolutionOwnerTitles: this.getUserTitles(listItem.GDSSolutionOwner),
                            // GDSSolutionOwner: (listItem.GDSSolutionOwner != undefined && listItem.GDSSolutionOwner != null ? listItem.GDSSolutionOwner : ''),
                            // GDSSolutionContributorsId: (listItem.GDSSolutionContributorsId != undefined && listItem.GDSSolutionContributorsId != null ? listItem.GDSSolutionContributorsId : ''),
                            // GDSSolutionContributorsTitles: this.getUserTitles(listItem.GDSSolutionContributors),
                            // GDSSolutionContributors: (listItem.GDSSolutionContributors != undefined && listItem.GDSSolutionContributors != null ? listItem.GDSSolutionContributors : ''),
                            // GDSPPEDDSponsorId: (listItem.GDSPPEDDSponsorId != undefined && listItem.GDSPPEDDSponsorId != null ? listItem.GDSPPEDDSponsorId : ''),
                            // GDSPPEDDSponsorTitles: this.getUserTitles(listItem.GDSPPEDDSponsor),
                            // GDSPPEDDSponsor: (listItem.GDSPPEDDSponsor != undefined && listItem.GDSPPEDDSponsor != null ? listItem.GDSPPEDDSponsor : ''),
                            // GDSBenefitsOfTeamDescription: (listItem.GDSBenefitsOfTeamDescription != undefined && listItem.GDSBenefitsOfTeamDescription != null ? listItem.GDSBenefitsOfTeamDescription : ''),
                            // GDSSolutionEnhancements: (listItem.GDSSolutionEnhancements != undefined && listItem.GDSSolutionEnhancements != null ? listItem.GDSSolutionEnhancements : ''),
                            // GDSSolutionEnhanceYesNo: (listItem.GDSSolutionEnhanceYesNo != undefined && listItem.GDSSolutionEnhanceYesNo != null ? listItem.GDSSolutionEnhanceYesNo : ''),
                            // GDSEstimatedHours: (listItem.GDSEstimatedHours != undefined && listItem.GDSEstimatedHours != null ? listItem.GDSEstimatedHours : ''),
                            // GDSStatus: (listItem.GDSStatus != undefined && listItem.GDSStatus != null ? listItem.GDSStatus : ''),
                            // GDSSolutionID: (listItem.GDSSolutionID != undefined && listItem.GDSSolutionID != null ? listItem.GDSSolutionID : ''),
                            // GDSPrimaryObjective: (listItem.GDSPrimaryObjective != undefined && listItem.GDSPrimaryObjective != null ? listItem.GDSPrimaryObjective : ''),
                            // GDSPrimaryObjectiveOther: (listItem.GDSPrimaryObjectiveOther != undefined && listItem.GDSPrimaryObjectiveOther != null ? listItem.GDSPrimaryObjectiveOther : ''),
                            // GDSRelatedAccount: (listItem.GDSRelatedAccount != undefined && listItem.GDSRelatedAccount != null ? listItem.GDSRelatedAccount : ''),
                            // GDSSummaryOfChanges: (listItem.GDSSummaryOfChanges != undefined && listItem.GDSSummaryOfChanges != null ? listItem.GDSSummaryOfChanges : ''),
                            // GDSPromptedTheChange: (listItem.GDSPromptedTheChange != undefined && listItem.GDSPromptedTheChange != null ? listItem.GDSPromptedTheChange : ''),                            
                            // GDSAck1: (listItem.GDSAck1 != undefined && listItem.GDSAck1 != null ? listItem.GDSAck1 : ''),
                            // GDSAck2: (listItem.GDSAck2 != undefined && listItem.GDSAck2 != null ? listItem.GDSAck2 : ''),
                            // GDSAck3: (listItem.GDSAck3 != undefined && listItem.GDSAck3 != null ? listItem.GDSAck3 : ''),
                            // GDSAck4: (listItem.GDSAck4 != undefined && listItem.GDSAck4 != null ? listItem.GDSAck4 : ''),
                            // GDSAck5: (listItem.GDSAck5 != undefined && listItem.GDSAck5 != null ? listItem.GDSAck5 : ''),
                            // Created: listItem.Created,
                            // Modified: listItem.Modified,
                            // FormName: FormName,
                            // GDSNewOrUpdateSolution: (listItem.GDSNewOrUpdateSolution != undefined && listItem.GDSNewOrUpdateSolution != null ? listItem.GDSNewOrUpdateSolution : '')                          
                        // });
                    });
                    resolve(listData);
                });
        });
    }



    public static getSupportListItemData(requestUrl: string, spHttpClient: SPHttpClient): any {
        let listData: IGDSSupportItem[] = [];
        return new Promise<IGDSSupportItem[]>((resolve: (options: IGDSSupportItem[]) => void, reject: (error: any) => void) => {
            return SPData.getListData(requestUrl, spHttpClient)
                .then((listItems) => {
                    listItems.map(listItem => {
                        listData.push({
                            Id: listItem.Id,
                            Title: (listItem.Title != undefined && listItem.Title != null ? listItem.Title : ''),
                            GDSSupportAreaOwners: (listItem.GDSSupportAreaOwners != undefined && listItem.GDSSupportAreaOwners != null ? listItem.GDSSupportAreaOwners : ''),
                            GDSSupportAreaReviewers: (listItem.GDSSupportAreaReviewers != undefined && listItem.GDSSupportAreaReviewers != null ? listItem.GDSSupportAreaReviewers : ''),    
                            GDSSupportCertifiedSolutions: (listItem.GDSSupportCertifiedSolutions != undefined && listItem.GDSSupportCertifiedSolutions != null ? listItem.GDSSupportCertifiedSolutions : ''),
                            GDSSupportCertifications: (listItem.GDSSupportCertifications != undefined && listItem.GDSSupportCertifications != null ? listItem.GDSSupportCertifications : ''),
                            GDSSupportPolicyLink: (listItem.GDSSupportPolicyLink != undefined && listItem.GDSSupportPolicyLink != null ? listItem.GDSSupportPolicyLink : ''),
                            GDSSupportYammerLink: (listItem.GDSSupportYammerLink != undefined && listItem.GDSSupportYammerLink != null ? listItem.GDSSupportYammerLink : ''),
                            GDSWorkflowStep1: (listItem.GDSWorkflowStep1 != undefined && listItem.GDSWorkflowStep1 != null ? listItem.GDSWorkflowStep1 : ''),
                            GDSWorkflowStep2: (listItem.GDSWorkflowStep2 != undefined && listItem.GDSWorkflowStep2 != null ? listItem.GDSWorkflowStep2 : ''),    
                            GDSWorkflowStep3: (listItem.GDSWorkflowStep3 != undefined && listItem.GDSWorkflowStep3 != null ? listItem.GDSWorkflowStep3 : ''),
                            GDSWorkflowStep4: (listItem.GDSWorkflowStep4 != undefined && listItem.GDSWorkflowStep4 != null ? listItem.GDSWorkflowStep4 : ''),
                            GDSWorkflowFinalStep: (listItem.GDSWorkflowFinalStep != undefined && listItem.GDSWorkflowFinalStep != null ? listItem.GDSWorkflowFinalStep : ''),   
                        });
                    });
                    resolve(listData);
                });
            });
        }




        public static getTrackLikesItemData(requestUrl: string, spHttpClient: SPHttpClient): any {
            let listData: IGDSTrackLikesItem[] = [];
            return new Promise<IGDSTrackLikesItem[]>((resolve: (options: IGDSTrackLikesItem[]) => void, reject: (error: any) => void) => {
                return SPData.getListData(requestUrl, spHttpClient)
                    .then((listItems) => {
                        listItems.map(listItem => {
                            listData.push({
                                Id: listItem.Id,
                                Title: (listItem.Title != undefined && listItem.Title != null ? listItem.Title : ''),                                
                                GDSSolutionID: (listItem.GDSSolutionID != undefined && listItem.GDSSolutionID != null ? listItem.GDSSolutionID : ''),
                                GDSTrackLikes: listItem.GDSTrackLikes,
                                GDSDownloads: listItem.GDSDownloads,
                                GDSLikesUsers: (listItem.GDSLikesUsers != undefined && listItem.GDSLikesUsers != null ? listItem.GDSLikesUsers : ''),
                                eTag: listItem["@odata.etag"]                               
                            });
                        });
                        resolve(listData);
                    });
            });
        }

        public static getAnnualConfirmationListItemData(requestUrl: string, spHttpClient: SPHttpClient): any {
            let listData: IGDSSolutionOwnerAnnualConfirmationItem[] = [];
            return new Promise<IGDSSolutionOwnerAnnualConfirmationItem[]>((resolve: (options: IGDSSolutionOwnerAnnualConfirmationItem[]) => void, reject: (error: any) => void) => {
                return SPData.getListData(requestUrl, spHttpClient)
                    .then((listItems) => {
                        listItems.map(listItem => {
                            listData.push({
                                Id: listItem.Id,
                                Title: (listItem.Title != undefined && listItem.Title != null ? listItem.Title : ''),                                
                                GDSSolutionID: (listItem.GDSSolutionID != undefined && listItem.GDSSolutionID != null ? listItem.GDSSolutionID : ''),
                                GDSAnnualConfirmation: listItem.GDSAnnualConfirmation                                                           
                            });
                        });
                        resolve(listData);
                    });
            });
        }

        public static getGDSConfigurationsItemData(requestUrl: string, spHttpClient: SPHttpClient): any {
            let listData: IGDSConfigurationItem[] = [];
            return new Promise<IGDSConfigurationItem[]>((resolve: (options: IGDSConfigurationItem[]) => void, reject: (error: any) => void) => {
                return SPData.getListData(requestUrl, spHttpClient)
                    .then((listItems) => {
                        listItems.map(listItem => {
                            listData.push({
                                Id: listItem.Id,
                                Title: (listItem.Title != undefined && listItem.Title != null ? listItem.Title : ''),
                                Value: (listItem.Value != undefined && listItem.Value != null ? listItem.Value : ''),
                                GDSDate: (listItem.GDSDate != undefined && listItem.GDSDate != null ? listItem.GDSDate : '') 
                            });
                        });
                        resolve(listData);
                    });
            });
        }

    static getRegionalGeog(GDSRegionalGeography: any): string[] {
        let regions = [];
        if (GDSRegionalGeography != null && GDSRegionalGeography.length > 0) {
            regions = GDSRegionalGeography.split(";");            
        }
        return regions;
    }

    static getUserTitles(UserObjArr: any): string[] {
        let titles: string[] = [];
        if (UserObjArr != null && UserObjArr.length > 0) {
            UserObjArr.map(contributor => {
                titles.push(contributor.Title);
            });
        }
        else if (UserObjArr != null && UserObjArr.Title != undefined) {
            titles.push(UserObjArr.Title);
        }
        return titles.filter(item => item != null && item != "" && item != undefined);
    }

    static getLookUpIds(LookUpObjArr: any): string[] {
        let lookupIds: string[] = [];
        if (LookUpObjArr != null && LookUpObjArr.length > 0) {
            LookUpObjArr.map(contributor => {
                lookupIds.push(contributor.Id);
            });
        }
        else if (LookUpObjArr != null) {
            lookupIds.push(LookUpObjArr.Id);
        }
        return lookupIds.filter(item => item != null && item != "" && item != undefined);
    }
    
    static getDropDownOptionsFromArray(Form_StatusArray: string[], LoggedInUserType) {
        let dropDownOptions: IGDSDropDownStruct[] = [];

        Form_StatusArray.map((option) => {
            var disabledVal = false;
                //Enabling options for reviewer - Pending Approval, Rejected for FORM1 (Archival Form)
                //Enabling options for reviewer - "Unpublished","Ready to publish","Published","Revoked" for FORM2 (MarketPlace Form)
                if(LoggedInUserType == "reviewer" && (option == "Approved"                       
                                    || option == "Published"))
                    {
                        disabledVal =  true;
                    }

                //Enabling options for owner - Approved
                if(LoggedInUserType == "owner" && (option == "Pending Approval"                                    
                                    || option == "Rejected"))
                    {
                        disabledVal =  true;
                    }

                // //Enabling options for both (Reviewer and Owner) - Approved
                // disabledVal = (LoggedInUserType == "both" && (option == "Submitted" 
                //                     || option == "Pending Approval"
                //                     || option == "Rejected"
                //                     || option == "Approved") )            
            
            dropDownOptions.push({
                key: option,
                text: option,
                disabled: disabledVal
            });
        });
        return dropDownOptions;
     } 

    public static getDropDownOptions(listData: any[], ColumnName: string) {
        let dropDownOptions: IGDSDropDownStruct[] = [];
        var optionAll = constants.SPFXConstants.Constants.DropDownOptionALL;
        //To Add 'ALL' Option
        dropDownOptions.push({
            key: optionAll,
            text: optionAll,
            disabled: false
        })

        listData.map((option) => {
            dropDownOptions.push({
                key: option[ColumnName],
                text: option[ColumnName],
                disabled: false
            });
        });

        return dropDownOptions;
    }

    public static getMultiSelectDropDownOptions(listData: any[], ColumnName: string) {
        let dropDownOptions: IGDSMultiDropDownStruct[] = [];
        // var optionAll = constants.SPFXConstants.Constants.DropDownOptionALL;
        // //To Add 'ALL' Option
        // dropDownOptions.push({
        //     key: optionAll,
        //     text: optionAll,
        //     disabled: false
        // })

        listData.map((option, index) => {
            dropDownOptions.push({
                key: index,
                text: option[ColumnName],
                disabled: false
            });
        });

        return dropDownOptions;
    }

    public static getLookUpAsDropDownOptions(listData: any[], ColumnName: string) {
        let dropDownOptions: IGDSDropDownStruct[] = [];
        var optionAll = constants.SPFXConstants.Constants.DropDownOptionALL;
        //To Add 'ALL' Option
        dropDownOptions.push({
            key: optionAll,
            text: optionAll,
            disabled: false
        })

        listData.map((option) => {
            dropDownOptions.push({
                key: option["Id"],
                text: option[ColumnName],
                disabled: false
            });
        });

        return dropDownOptions;
    }

    public static getSolutionTitles(listData: any[]) {

        let dropDownOptions: IGDSDropDownStruct[] = [];
        listData.map((option) => {
            dropDownOptions.push({
                key: option.GDSSolutionID,
                text: option.GDSName,
                disabled: false
            });
        });

        return dropDownOptions;
    }

    public static SubmitReportBug(restUrl: string, headers: {}, formData: any, metadataType:string, absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient): any {
        
        var itemObj = {};        

        let form = Object.keys(formData);

        itemObj["__metadata"] = { type: metadataType};
        
        form.map((key, index) => {
            if (formData[key] != "")
            itemObj[key] = formData[key];
        });

        return SPData.AddItem(itemObj, restUrl, headers, spHttpClient)
                .then((response: SPHttpClientResponse): Promise<any> => {
                    console.log('response.json()');
                    return response.json();
                }).then((item) => {
                    console.log("Bug submitted successfully");
                    return item
                }, (error: any): void => {
                    //this.usermessage('List Item Creation Error...');
                    console.log("Failed to report bug");
                })

        // return Promise.all(form.map((key, index) => {
        //     if (formData[key] != "")
        //     itemObj[key] = formData[key];
        // })).then((data) => {
        //     return SPData.AddItem(itemObj, restUrl, headers, spHttpClient)
        //         .then((response: SPHttpClientResponse): Promise<any> => {
        //             console.log('response.json()');
        //             return response.json();
        //         }).then((item) => {
        //             console.log("Solution submitted successfully");
        //             return item
        //         }, (error: any): void => {
        //             //this.usermessage('List Item Creation Error...');
        //             console.log("Failed to submit solution");
        //         })
        // });
    }

    public static SubmitLikesDownloadCount(restUrl: string, headers: {}, formData: any, metadataType:string, spHttpClient: SPHttpClient): any {
        
        var itemObj = {};        

        let form = Object.keys(formData);

        itemObj["__metadata"] = { type: metadataType};
        
        form.map((key, index) => {
            if (formData[key] != "")
            itemObj[key] = formData[key];
        });

        return SPData.AddItem(itemObj, restUrl, headers, spHttpClient)
                .then((response: SPHttpClientResponse): Promise<any> => {
                    return new Promise<any>((resolve, reject) => {
                        if (response.ok) {
                        // response.json().then((responseJSON) => {
                        //         resolve(responseJSON);
                        //     });
                        resolve("Success");
                        }
                        else {
                            // response.text().then((responseText) => {
                            //     reject(responseText);
                            // });
                            reject("Fail");
                        }
                    });
                });

        // return SPData.AddItem(itemObj, restUrl, headers, spHttpClient)
        //         .then((response: SPHttpClientResponse): Promise<any> => {
        //             console.log('response.json()');
        //             return response.json();
        //         }).then((item) => {
        //             alert("Click submitted successfully");
        //             return item
        //         }, (error: any): void => {
        //             //this.usermessage('List Item Creation Error...');
        //             console.log("Failed to submit click");
        //         });
    }

    static DeleteItem(restUrl: string, headers: {}, metadataType:string, absoluteUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient): any {
        return SPData.DeleteItem(restUrl, headers, spHttpClient)
                .then((response: SPHttpClientResponse): Promise<any> => {
                    return new Promise<any>((resolve, reject) => {
                        if (response.ok) {                        
                            resolve("Success");
                        }
                        else {                           
                            reject("Fail");
                        }
                    });
                });
    }   


    public static SubmitSolution(restUrl: string, headers: {}, formData: any, metadataType:string, absoluteUrl: string, listUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient): any {
        //Creating userObj as PPLPicker allows multiple users to add
        var itemObj = {};
        var userObj = {};
        /*if(AssignedUserId["results"] == undefined)
        {
            let multiUserArrayFormat: string[] = [];
            multiUserArrayFormat.push(AssignedUserId);
            userObj["results"] = multiUserArrayFormat;
        }*/

        let form = Object.keys(formData);

        itemObj["__metadata"] = { type: metadataType };
        return Promise.all(form.map((key, index) => {
            if (formData[key] != null && formData[key] != "") {
                /* Checks formName == Archive and saves SolutionPPEDDSponsor (pplpicker) value to SPList.
                For Form 'Markeplace', no need to save SolutionPPEDDSponsor pplpicker value */
                if ((key == constants.SPFXConstants.Constants.InternalName_SolutionPPEDDSponsor && formData["FormName"] == constants.SPFXConstants.Constants.ArchiveFormName)
                    || key == constants.SPFXConstants.Constants.InternalName_SolutionOwner
                    || key == constants.SPFXConstants.Constants.InternalName_SolutionContributors) {

                    let pplPickerColumnId = key + "Id";
                    if (Array.isArray(formData[key]) && formData[key][0]["id"] != undefined) {
                        return SPData.getUserIdByAccountName(formData[key], absoluteUrl, spHttpClient)
                            .then((userIdsArray) => {
                                if (userIdsArray.length > 0) {
                                    itemObj[pplPickerColumnId] = GDSService.constructMultipleUserOrSelectArray(userIdsArray, key);
                                }
                            })
                    }
                    else {
                        //Since solution contributors allows multiple users, have to construct the user object in structured manner
                        if (key == constants.SPFXConstants.Constants.InternalName_SolutionContributors)
                            itemObj[pplPickerColumnId] = GDSService.constructMultipleUserOrSelectArray(formData[pplPickerColumnId], key);
                        else
                            itemObj[pplPickerColumnId] = formData[pplPickerColumnId];
                    }
                }
                else if (key == constants.SPFXConstants.Constants.InternalName_SolutionTypeMulti || key == constants.SPFXConstants.Constants.InternalName_SolutionSectorMulti) {
                    let multiSelectColumnId = key + "Id";
                    itemObj[multiSelectColumnId] = GDSService.constructMultipleUserOrSelectArray(formData[key], key);
                }
                else if (key == constants.SPFXConstants.Constants.InternalName_SolutionRegion || key == constants.SPFXConstants.Constants.InternalName_SolutionRegion_Restrictions) {
                    if (formData[key].length > 0) {
                        let multiSelectRegionalColumnValue = '';
                        let selectedRegions = formData[key];
                        selectedRegions = selectedRegions.filter(v => v != ''); //removing any blank values from array
                        selectedRegions.map(region => {
                            multiSelectRegionalColumnValue += region + ";"
                        })
                        itemObj[key] = multiSelectRegionalColumnValue;
                    }
                }
                //Following Columns are not available in SP list, used for temporary columns 
                else if (key != constants.SPFXConstants.Constants.InternalName_SolutionPPEDDSponsor + "Titles"
                    && key != constants.SPFXConstants.Constants.InternalName_SolutionOwner + "Titles"
                    && key != constants.SPFXConstants.Constants.InternalName_SolutionContributors + "Titles"
                    && key != constants.SPFXConstants.Constants.InternalName_SolutionTypeMulti + "Titles"
                    && key != constants.SPFXConstants.Constants.InternalName_SolutionSectorMulti + "Titles"
                    && key != constants.SPFXConstants.Constants.InternalName_ID_Column
                    && key != "FormName") {
                    if (formData[key] != "")
                        itemObj[key] = formData[key];
                }
            }
        })).then((data) => {
            return SPData.AddItem(itemObj, restUrl, headers, spHttpClient)
                .then((response: SPHttpClientResponse): Promise<any> => {
                    console.log('response.json()');
                    return response.json();
                }).then((item) => {
                    console.log("Solution submitted successfully");
                    return item
                }, (error: any): void => {
                    //this.usermessage('List Item Creation Error...');
                    console.log("Failed to submit solution");
                })
        });
    }

    private static constructMultipleUserOrSelectArray(IdsArray: any, key: string) {
        var multiSelectIds = {};
        if (IdsArray.length > 0
            && (key == constants.SPFXConstants.Constants.InternalName_SolutionContributors 
                    || key == constants.SPFXConstants.Constants.InternalName_SolutionTypeMulti
                    || key == constants.SPFXConstants.Constants.InternalName_SolutionSectorMulti)) {
            //{ "results": ["4", "7"] }
            var resultsArray: string[] = [];
            IdsArray = IdsArray.filter(v => v != '' && v != null && v != undefined);
            IdsArray.map(multiSelectId => {
                resultsArray.push(multiSelectId);
            });
            multiSelectIds["results"] = resultsArray; // Multiple users or select format obj["results"]                               
            return multiSelectIds;
        }
        else {
            //single user
            return IdsArray[0];
        }
    }

    public static getLoggedInUserSPGroups(webAbsoluteUrl: string, spHttpClient: SPHttpClient) {
        return new Promise<string[]>
          ((resolve: (options: string[]) => void, reject: (error: any) => void) => {         
            return SPData.getCurrentUserGroupNames(webAbsoluteUrl, spHttpClient)            
              .then((groupNamesArray) => {
                resolve(groupNamesArray);
              });
          });
      }

    
      public static getUniqueAreasBasedOnGroups(SPGroups: string[]) {
        var SPGroupsToCheck = [{ Area: "Americas", AreaGroupName: "Americas Area Owner" },
        { Area: "Americas", AreaGroupName: "Americas Area Reviewer" },
        { Area: "ASIAPAC", AreaGroupName: "ASIAPAC Area Owner" },
        { Area: "ASIAPAC", AreaGroupName: "ASIAPAC Area Reviewer" },
        { Area: "EMEIA", AreaGroupName: "EMEIA Area Owner" },
        { Area: "EMEIA", AreaGroupName: "EMEIA Area Reviewer" }];
        
        //Compares SPGroupsToCheck array with retrieved groups from Site
        var userBelongsToGroups = SPGroupsToCheck.filter(function (spGroupName) {
           return SPGroups.some(function (group) {
              return spGroupName.AreaGroupName === group["Title"]; // assumes unique id
           });
        });
        //gets Area property values from the object array and then gets distinct values
        const userBelongsToAreasArray = userBelongsToGroups.map(user => user.Area)
           .filter((value, index, self) => self.indexOf(value) === index);
           return userBelongsToAreasArray;
     }


     public static getUserRegionGroups(SPGroups: string[]) {
        var SPGroupsToCheck = [{ Area: "Americas", AreaGroupName: "Americas Area Owner" },
        { Area: "Americas", AreaGroupName: "Americas Area Reviewer" },
        { Area: "ASIAPAC", AreaGroupName: "ASIAPAC Area Owner" },
        { Area: "ASIAPAC", AreaGroupName: "ASIAPAC Area Reviewer" },
        { Area: "EMEIA", AreaGroupName: "EMEIA Area Owner" },
        { Area: "EMEIA", AreaGroupName: "EMEIA Area Reviewer" }];
        
        //Compares SPGroupsToCheck array with retrieved groups from Site
        var userBelongsToGroups = SPGroupsToCheck.filter(function (spGroupName) {
           return SPGroups.some(function (group) {
              return spGroupName.AreaGroupName === group["Title"]; // assumes unique id
           });
        });

        return userBelongsToGroups;
    }

      static getDateFormat(solutionDate: string): React.ReactNode {

          var date = new Date(solutionDate);
          var ddstring ='';
          var mmstring = '';
          var dd = date.getDate();          
          var mm = date.getMonth() + 1;
          var yyyy = date.getFullYear();          
          ddstring = (dd < 10 ? '0' + dd : dd.toString());
          mmstring = (mm < 10 ? '0' + mm : mm.toString());
          
          return ddstring + '/' + mmstring + '/' + yyyy; 
       }

    static getDateDiffInDays(CreatedDate: string): React.ReactNode {

        // To set two dates to two variables 
        var solutionCreatedDate = new Date(CreatedDate);
        var currentDate = new Date();

        // To calculate the time difference of two dates 
        var Difference_In_Time = currentDate.getTime() - solutionCreatedDate.getTime();

        // To calculate the no. of days between two dates 
        var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);

        return Difference_In_Days;
    }

    static getMonthName(monthIndex): React.ReactNode {
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", 
                            "August", "September", "October", "November", "December"];
        
        return monthNames[monthIndex];
    }
       

       static getStatusColor(status: string) {
        switch(status){
           case constants.SPFXConstants.Constants.FormStatus_Submitted.toLowerCase(): return "blue"
           case constants.SPFXConstants.Constants.FormStatus_Draft.toLowerCase():
           case constants.SPFXConstants.Constants.FormStatus_PendingApproval.toLowerCase():
           case constants.SPFXConstants.Constants.FormStatus_ReadyToPublish.toLowerCase(): return "orange"
           case constants.SPFXConstants.Constants.FormStatus_Rejected.toLowerCase():
           case constants.SPFXConstants.Constants.FormStatus_Revoked.toLowerCase(): return "red"
           case constants.SPFXConstants.Constants.FormStatus_Approved.toLowerCase():
           case constants.SPFXConstants.Constants.FormStatus_Published.toLowerCase(): return "green"
           case constants.SPFXConstants.Constants.FormStatus_Unpublished.toLowerCase(): return "palegreen"
        }
       }

       public static clickLikesDownloadCount(solutionId: string, solutionName: string, loggedInUserEmail:string, clickType:string, absoluteUrl: string, serverRelativeUrl: string, spHttpClient: SPHttpClient): any {
          
                   let restUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + constants.SPFXConstants.Constants.GDSTrackLikesListUrl + "')/items"
                       + "?$filter=GDSSolutionID eq '" + solutionId + "'"
                       + "&$select=*");

        return GDSService.getTrackLikesItemData(restUrl, spHttpClient)
                 .then((listData) => {
                    //console.log(listData);                                   
                    //Item Found and update the item
                    if(listData.length > 0)
                    {
                        if (listData[0].GDSLikesUsers.indexOf(loggedInUserEmail) == -1 || clickType.toLowerCase() == "download") 
                        {
                            var LikeCounter = (clickType.toLowerCase() == "like" ? listData[0].GDSTrackLikes + 1 : listData[0].GDSTrackLikes);
                            var DownloadCounter = (clickType.toLowerCase() == "download" ? listData[0].GDSDownloads + 1 : listData[0].GDSDownloads);
                            var UpdatedLikeUsers = listData[0].GDSLikesUsers + loggedInUserEmail + ';';
                            let submitLikes = {
                                GDSSolutionID: solutionId,
                                Title: solutionName,
                                GDSTrackLikes: LikeCounter,
                                GDSDownloads: DownloadCounter,
                                GDSLikesUsers: UpdatedLikeUsers
                            }
                            let restUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + constants.SPFXConstants.Constants.GDSTrackLikesListUrl + "')/items(" + listData[0].Id + ")");
                            const headers = {
                                "accept": "application/json;odata=verbose",
                                "content-Type": "application/json;odata=verbose",
                                "IF-MATCH": listData[0].eTag,
                                "X-HTTP-Method": "MERGE",
                                'odata-version': ''
                            }
                            return GDSService.submitLikesDownloadData(restUrl, submitLikes, headers, spHttpClient)
                                .then((status) => {
                                    return (status == "Success" ? submitLikes : -1); //Success: like value; Fail: -1
                                })
                        }
                        //if user already liked the solution
                        else {
                            return "UserAlreadyLiked";
                        }
                    }
                    //Item not found, create new item
                    else
                    {
                       var likeCounter = (clickType.toLowerCase() == "like" ? 1 : 0);
                       var downloadCounter = (clickType.toLowerCase() == "download" ? 1 : 0);
                       var UpdatedLikeUsers = loggedInUserEmail + ';';
                       let submitLikes = {
                          GDSSolutionID: solutionId,
                          Title: solutionName,
                          GDSTrackLikes: likeCounter,
                          GDSDownloads: downloadCounter,
                          GDSLikesUsers: UpdatedLikeUsers
                       }
                       let restUrl = absoluteUrl.concat("/_api/Web/GetList('" + serverRelativeUrl + constants.SPFXConstants.Constants.GDSTrackLikesListUrl + "')/items")
                       const headers = {
                             "accept": "application/json;odata=verbose",
                             "content-Type": "application/json;odata=verbose",
                             "X-HTTP-Method": "POST",
                             'odata-version': ''
                         };
                         return this.submitLikesDownloadData(restUrl, submitLikes, headers, spHttpClient)
                             .then((status) => {
                                 return (status == "Success" ? submitLikes : -1);
                             })
                     }
                 });
      
     }
     
    public static submitLikesDownloadData(restUrl: string, submitLikes: any, headers: any, spHttpClient: SPHttpClient): any {
        let metadataType = "SP.Data.GDSTrackLikesListItem";
        var _self = this;
        return GDSService.SubmitLikesDownloadCount(restUrl, headers, submitLikes, metadataType, spHttpClient)
            .then((item) => {
                if (!item.error) {
                    console.log("Success");
                    return "Success"
                }
                else {
                    console.log("Fail");
                    return "Failed...Like Not Updated";
                }
            });
    }

     static getSolutionLikeCount(TrackLikesData: any[], GDSSolutionID: any): React.ReactNode {
        var trackLikeItem = TrackLikesData.filter(solution => solution.GDSSolutionID === GDSSolutionID);
        if (trackLikeItem.length > 0) {
            return trackLikeItem[0].GDSTrackLikes;
        }
        else {
            return 0;
        }
    }

    static getSolutionLikeColorClassName(userLiked: boolean): string {
            if (userLiked === true) {
                return "blue";
            }           
        return "grey";        
    }
    
    
    public static SubmitAnnualConfirmation(restUrl: string, headers: {}, formData: any, metadataType:string, spHttpClient: SPHttpClient): any {
        
        var itemObj = {};        

        let form = Object.keys(formData);

        itemObj["__metadata"] = { type: metadataType};
        
        form.map((key, index) => {
            if (formData[key] != "")
            itemObj[key] = formData[key];
        });

        return SPData.AddItem(itemObj, restUrl, headers, spHttpClient)
                .then((response: SPHttpClientResponse): Promise<any> => {
                    return new Promise<any>((resolve, reject) => {
                        if (response.ok) {                       
                            resolve("Success");
                        }
                        else {                           
                            reject("Fail");
                        }
                    });
                });
    }

    static getConfigValue(configurations: any[], configTitle: string): any {        
       var configItem = configurations.filter(item => item["Title"] == configTitle);
        if(configItem.length > 0)
            return configItem[0]["Value"];
        else
            return "";
     }   

    //Usage - ascending order -  list.sort(columnName);
    //Usage - descending order - list.sort(columnName, 'desc');
    static compareValues(key, order = 'asc') {
        return function innerSort(a, b) {
            if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
                // property doesn't exist on either object
                return 0;
            }

            const varA = (typeof a[key] === 'string')
                ? a[key].toUpperCase() : a[key];
            const varB = (typeof b[key] === 'string')
                ? b[key].toUpperCase() : b[key];

            let comparison = 0;
            if (varA > varB) {
                comparison = 1;
            } else if (varA < varB) {
                comparison = -1;
            }
            return (
                (order === 'desc') ? (comparison * -1) : comparison
            );
        };
    }
    public getDefaultImgUrl(absoluteUrl: string): string {
        return String.Format(Constants.SPFXConstants.Constants.carousalImages );
    }
        
    static formatSolutionColumnValue(solutionColumnValues: any): React.ReactNode {        
        solutionColumnValues = solutionColumnValues.filter(v => v != '');
        let colValueLen = solutionColumnValues.length;   
        return solutionColumnValues.map((value, index) => {
            if (colValueLen === index + 1) {
                return value;
            } else {
                return value + ",";
            }
        });
    }
}
